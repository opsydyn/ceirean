bun run check
