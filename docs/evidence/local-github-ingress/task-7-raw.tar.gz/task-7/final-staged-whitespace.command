git diff --cached --check
