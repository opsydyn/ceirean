bun run lint
