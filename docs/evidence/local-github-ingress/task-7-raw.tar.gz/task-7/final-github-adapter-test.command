moon run github-adapter:test --force --no-actions
