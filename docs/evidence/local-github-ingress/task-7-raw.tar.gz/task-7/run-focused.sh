#!/bin/sh
set -u
id=$1
shift
out=docs/evidence/local-github-ingress/task-7
printf '%s\n' "$*" > "$out/$id.command"
env -i PATH="$PATH" HOME="$HOME" TMPDIR="${TMPDIR:-/private/tmp}" "$@" > "$out/$id.log" 2>&1
code=$?
printf '%s\n' "$code" > "$out/$id.exit"
exit "$code"
