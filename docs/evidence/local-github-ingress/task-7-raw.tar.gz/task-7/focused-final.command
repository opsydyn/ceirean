bun --no-env-file --no-install test apps/github-ingress/tests/qualification-report.test.ts apps/github-ingress/tests/restart.test.ts --timeout 30000
