moon run domain:test --force --no-actions
