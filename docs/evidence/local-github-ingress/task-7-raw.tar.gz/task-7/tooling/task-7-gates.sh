#!/bin/sh
set -eu
out=docs/evidence/local-github-ingress/task-7
run() {
  id=$1
  shift
  sh "$out/run-focused.sh" "final-$id" "$@"
}
case "${1:-full}" in
  full) run install bun install --frozen-lockfile --ignore-scripts ;;
  resume-after-format-fix) ;;
  *) exit 2 ;;
esac
run check bun run check
for workspace in domain engine probe github-admission github-adapter github-ingress; do
  run "$workspace-typecheck" moon run "$workspace:typecheck" --force --no-actions
done
for workspace in domain engine probe github-admission github-adapter github-ingress; do
  run "$workspace-test" moon run "$workspace:test" --force --no-actions
done
run whitespace git diff --check
run staged-whitespace git diff --cached --check
run integrity bun --no-env-file --no-install .superpowers/sdd/2026-10-20-local-github-ingress/task-7-measure.mjs verify
