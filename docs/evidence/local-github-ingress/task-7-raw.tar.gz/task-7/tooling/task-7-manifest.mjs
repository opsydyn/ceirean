import { readFileSync } from 'node:fs';
import { validateLocalQualification, qualificationGateIds } from '../../../apps/github-ingress/src/qualification-report.ts';
import { Result } from '../../../apps/github-ingress/node_modules/effect/dist/index.js';

const canonical = 'docs/evidence/local-github-ingress';
const out = `${canonical}/task-7`;
const read = (path) => readFileSync(path, 'utf8');
const hash = (bytes) => new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
const source = JSON.parse(read(`${out}/source.json`));
function git(...args) {
  const result = Bun.spawnSync(['git', ...args]);
  if (result.exitCode !== 0) throw new Error(result.stderr.toString());
  return result.stdout.toString().trim();
}
const commit = git('rev-parse', 'HEAD');
if (git('rev-parse', 'HEAD^{tree}') !== source.tree) throw new Error('Source commit/tree mismatch');
function raw(id) {
  const log = read(`${out}/${id}.log`);
  const exit = Number(read(`${out}/${id}.exit`));
  return { log, exit, logHash: hash(log) };
}
const gates = qualificationGateIds.map((id) => {
  const measured = raw(`final-${id.replace(':', '-')}`);
  return { id, exit: measured.exit, logHash: measured.logHash, sourceHash: source.filesHash };
});
const suites = ['domain', 'engine', 'probe', 'github-admission', 'github-adapter', 'github-ingress'].map((workspace) => {
  const { log } = raw(`final-${workspace}-test`);
  function number(pattern) {
    const match = log.match(pattern);
    if (!match) throw new Error(`Unmeasured suite: ${workspace}`);
    return Number(match[1]);
  }
  return { workspace, passed: number(/^\s*(\d+) pass$/m), failed: number(/^\s*(\d+) fail$/m), assertions: number(/^\s*(\d+) expect\(\) calls$/m) };
});
const definitions = [
  ['EvidenceBinding', 'evidence', 'evidence', 'packages/github-adapter/src/live-sqlite-storage.ts', 'packages/github-adapter/tests/live-sqlite-inbox.test.ts', '"Duplicate"', '"InvalidData"'],
  ['PolicyRevision', 'policy', 'policy', 'packages/github-adapter/src/live-sqlite-inbox.ts', 'packages/github-adapter/tests/live-sqlite-inbox.test.ts', '"Installed"', '"AuthorityChanged"'],
  ['ReplayUniqueness', 'replay-v2', 'replay', 'packages/github-adapter/src/live-sqlite-inbox.ts', 'packages/github-adapter/tests/live-sqlite-inbox.test.ts', '"Absent"', '"Duplicate"'],
  ['TransactionRollback', 'rollback', 'rollback', 'packages/github-adapter/src/live-sqlite-inbox.ts', 'packages/github-adapter/tests/live-sqlite-inbox.test.ts', '"decisions": 1', '"decisions": 0'],
  ['AbortOwnership', 'abort-v2', 'abort', 'apps/github-ingress/src/listener.ts', 'apps/github-ingress/tests/listener.test.ts', 'Received: true', 'Expected: false'],
];
const bindings = [];
const controls = definitions.map(([name, prefix, identity, path, test, observed, intended]) => {
  const beforeHash = source.files[path];
  const restoredHash = read(`${out}/${identity}-restored.sha256`).split(/\s+/)[0];
  const mutatedHash = read(`${out}/${identity}-mutated.sha256`).split(/\s+/)[0];
  if (!read(`${out}/control-before.sha256`).includes(`${beforeHash}  ${path}`)) throw new Error('Unbound control source');
  const red = [1, 2].map((round) => {
    const result = raw(`${prefix}-red-${round}`);
    if (result.exit !== 1 || !result.log.includes('1 fail') || !result.log.includes(observed) || !result.log.includes(intended)) throw new Error(`Wrong control reason: ${name}`);
    return { exit: result.exit, logHash: result.logHash, reason: name };
  });
  const green = raw(`${prefix}-green`);
  if (green.exit !== 0 || !green.log.includes('1 pass') || !green.log.includes('0 fail')) throw new Error(`Control not GREEN: ${name}`);
  bindings.push({ name, path, test, testHash: source.files[test], logPrefix: prefix, identityPrefix: identity });
  return { name, beforeHash, mutatedHash, restoredHash, red, green: { exit: green.exit, logHash: green.logHash } };
});
const domain = raw('final-domain-test').log;
const engine = raw('final-engine-test').log;
if ((domain.match(/^\(pass\) live domain law:/gm) ?? []).length !== 4 || (engine.match(/^\(pass\) live engine law:/gm) ?? []).length !== 12) throw new Error('New law registration coverage changed');
const localQualification = {
  source: { commit, tree: source.tree, filesHash: source.filesHash, lockHash: source.lockHash },
  gates, suites,
  totals: { passed: suites.reduce((sum, suite) => sum + suite.passed, 0), failed: suites.reduce((sum, suite) => sum + suite.failed, 0), assertions: suites.reduce((sum, suite) => sum + suite.assertions, 0) },
  laws: { newPrimary: 24000, legacyPrimary: 168000, shrinks: 0 },
  controls, live: false, deployed: false,
};
const validated = Result.getOrThrow(validateLocalQualification(localQualification));
const index = JSON.parse(read(`${canonical}/accepted-tasks-1-6-index.json`));
const manifest = {
  schema: 'leviathan.local-github-ingress.qualification.v1',
  status: 'Task7CandidatePendingControllerReview',
  acceptedTasks: [1, 2, 3, 4, 5, 6],
  localQualification: validated,
  sourceInventory: 'local-github-ingress/task-7/source.json',
  rawLogs: { archive: 'local-github-ingress/task-7-raw.tar.gz', memberRoot: 'task-7/', sourceCommit: commit },
  historicalArchive: { path: 'local-github-ingress/accepted-tasks-1-6.tar.gz', sha256: index.sha256, byteComparedMembers: index.byteCompared, index: 'local-github-ingress/accepted-tasks-1-6-index.json' },
  controlBindings: bindings,
  lawAccounting: { seeds: [0, 1, 163], runsPerSeed: 1000, size: 50, maxShrinks: 1000, maxDiscards: 10000, newDomainLaws: 4, newEngineLaws: 4, legacyDomainLaws: 42, legacyEngineLaws: 14, primaryShrinks: 0, note: 'Primary laws passed without failure shrinking. Diagnostic false-property/shrink tests and behavioral controls are not primary cases; raw outputs retain diagnostics. Legacy domain = 13 receipt + 18 run + 6 command + 5 worker; legacy engine = 4 command + 7 safety + 3 constructive.' },
  review: { task7: 'PendingController', wholeBranch: 'PendingController', integration: 'NotAuthorized' },
  limitations: ['Initial Task 5 broad-batch RED history incomplete', 'Task 6 TDD excerpts are not raw gate logs', 'Task 3 M1 receipt display metadata and M2 permutation law deferred', 'Moon update notices preserved', 'No installer network trace or zero-network claim', 'No real key/API/tunnel/live/deployed qualification', 'Older snapshot restoration loses replay history', 'Pure validator checks supplied evidence consistency, not external truth', 'Initial final check failed generated JSON formatting; dependent gates stopped until formatting fixed', 'Initial replay and abort control test selections passed mutations and are retained as nonqualifying attempts'],
};
await Bun.write('docs/evidence/local-github-ingress.json', JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify({ source: validated.source, totals: validated.totals, suites: validated.suites, controls: validated.controls.map((control) => control.name), live: false, deployed: false }, null, 2));
