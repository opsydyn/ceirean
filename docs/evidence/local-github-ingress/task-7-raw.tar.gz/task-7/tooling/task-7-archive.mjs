import { readFileSync, readdirSync } from 'node:fs';
const scratch = '.superpowers/sdd/2026-10-20-local-github-ingress';
const canonical = 'docs/evidence/local-github-ingress';
const selected = new Set();
function add(path) { selected.add(path); }
function directory(path, filter = () => true) {
  for (const entry of readdirSync(`${scratch}/${path}`, { withFileTypes: true })) {
    const child = `${path}/${entry.name}`;
    if (entry.isDirectory()) directory(child, filter);
    else if (filter(child)) add(child);
  }
}
for (let task = 1; task <= 6; task++) {
  add(`task-${task}-report.md`);
  add(`task-${task}-review.md`);
}
for (const task of [3, 4, 5]) add(`task-${task}-rereview-1.md`);
add('progress.md');
add('task-7-evidence-handoff.md');
directory('task-1-evidence/full');
for (const name of ['post-gates-qualification.log', 'final-qualification.log', 'baseline-identities.log']) add(`task-1-evidence/${name}`);
directory('task-2-evidence', (path) => /\/(?:0[1-9]|1[0-3])-/.test(path) || /\/(?:audit-final|self-review-verified)\.json$/.test(path));
directory('task-3-evidence/round1');
directory('task-4-evidence/round1');
directory('task-5-evidence/fix-round-1');
directory('task-6-evidence');
const paths = [...selected].sort();
function hash(bytes) { return new Bun.CryptoHasher('sha256').update(bytes).digest('hex'); }
const members = paths.map((path) => {
  const bytes = readFileSync(`${scratch}/${path}`);
  if (/-----BEGIN (?:RSA )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{30}/.test(bytes.toString())) throw new Error(`Key material: ${path}`);
  return { path, bytes: bytes.length, sha256: hash(bytes) };
});
const archive = `${canonical}/accepted-tasks-1-6.tar.gz`;
const made = Bun.spawnSync(['tar', '-czf', `${process.cwd()}/${archive}`, '-C', scratch, ...paths]);
if (made.exitCode !== 0) throw new Error(made.stderr.toString());
for (const member of members) {
  const extracted = Bun.spawnSync(['tar', '-xOf', archive, member.path]);
  if (extracted.exitCode !== 0 || !extracted.stdout.equals(readFileSync(`${scratch}/${member.path}`))) throw new Error(`Archive mismatch: ${member.path}`);
}
const tracked = Bun.spawnSync(['git', 'ls-files', '-z', `${scratch}/task-6-report.md`, `${scratch}/task-6-evidence`]).stdout.toString().split('\0').filter(Boolean);
if (tracked.length !== 7 || tracked.some((path) => !selected.has(path.slice(scratch.length + 1)))) throw new Error('Tracked Task 6 relocation incomplete');
await Bun.write(`${canonical}/accepted-tasks-1-6-index.json`, JSON.stringify({ archive, sha256: hash(readFileSync(archive)), byteCompared: members.length, members, trackedTask6Copies: tracked }, null, 2) + '\n');
const rulings = readFileSync(`${scratch}/progress.md`, 'utf8').split('\n').filter((line) => line.startsWith('Ruling:'));
await Bun.write(`${canonical}/execution-decisions.md`, '# Execution Decisions\n\nLossless controller rulings from the plan ledger at Task 7 handoff. Historical\nstatements retain their original scope; Task 7 is a candidate pending review.\n\n' + rulings.join('\n\n') + '\n');
console.log(`Compared ${members.length}/${members.length} canonical archive members; ${tracked.length} tracked Task 6 copies preserved.`);
