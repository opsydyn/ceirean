import { readFileSync, realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import config from '../../../oxlint.config.ts';

const out = 'docs/evidence/local-github-ingress/task-7';
function command(...args) {
  const result = Bun.spawnSync(args, { stdout: 'pipe', stderr: 'pipe' });
  if (result.exitCode !== 0) throw new Error(`${args.join(' ')}: ${result.stderr}`);
  return result.stdout.toString().trim();
}
function hash(bytes) { return new Bun.CryptoHasher('sha256').update(bytes).digest('hex'); }
const paths = command('git', 'ls-files', '-z').split('\0').filter((path) => path && !path.startsWith('docs/') && !path.startsWith('.superpowers/') && !path.endsWith('.md')).sort();
const files = Object.fromEntries(paths.map((path) => [path, hash(readFileSync(path))]));
const filesHash = hash(JSON.stringify(files));
const lockHash = files['bun.lock'];
if (lockHash !== '8cb4d58bd88280daee28101e542cd9b7120ec7ee63dd5094daf59c2a45fddf59') throw new Error('Lock changed');
const workspaces = ['packages/domain', 'packages/engine', 'probes/bun-effect-flue', 'probes/github-admission', 'packages/github-adapter', 'apps/github-ingress'];
const physicalEffect = workspaces.map((path) => realpathSync(createRequire(`${process.cwd()}/${path}/package.json`).resolve('effect/package.json')));
if (new Set(physicalEffect).size !== 1) throw new Error('Multiple Effect installations');
if (JSON.parse(readFileSync(physicalEffect[0], 'utf8')).version !== '4.0.5') throw new Error('Wrong Effect');
const rules = Object.entries(config.rules).filter(([name]) => name.startsWith('linteffect/'));
if (rules.length !== 141 || rules.some(([,value]) => (Array.isArray(value) ? value[0] : value) !== 'error')) throw new Error('Rule severity changed');
const root = JSON.parse(readFileSync('package.json', 'utf8'));
if (root.overrides['@effect/platform-node-shared'] !== '4.0.5') throw new Error('Override changed');
for (const [path, expected] of Object.entries({ 'patches/@flue%2Fruntime@2.3.0.patch': '07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a', 'patches/gaxios@7.3.1.patch': '7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e' })) {
  if (files[path] !== expected) throw new Error(`Patch changed: ${path}`);
}
const base = 'e8fb83c437ebcf1709be4f0e119597319728c653';
if (command('git', 'diff', base, '--', 'bun.lock', 'patches', 'package.json', 'oxlint.config.ts', '.moon', 'packages', 'probes')) throw new Error('Out of scope source change');
const production = paths.filter((path) => /^(apps|packages)\/.+\/src\/.+\.ts$/.test(path));
const graph = {};
const transpiler = new Bun.Transpiler({ loader: 'ts' });
for (const path of production) {
  const text = readFileSync(path, 'utf8');
  const imports = transpiler.scanImports(text).map((entry) => entry.path);
  graph[path] = imports;
  if (imports.some((name) => name.startsWith('node:') || /^(?:@octokit|hono)(?:\/|$)/.test(name))) throw new Error(`Forbidden import: ${path}`);
  if (path.startsWith('apps/github-ingress/') || path.startsWith('packages/github-adapter/')) {
    if (/process\s*(?:\.|\[\s*['"])env|(?:Effect\.Effect|Layer\.Layer)\s*</.test(text)) throw new Error(`Environment/manual channel escape: ${path}`);
  }
  if (path.startsWith('apps/github-ingress/') && (imports.some((name) => name.startsWith('node:')) || /process\.env|Effect\.run|Layer\.launch|Effect\.provide/.test(text))) throw new Error(`Runtime escape: ${path}`);
  if (path.startsWith('packages/engine/') && imports.some((name) => /flue|github-adapter|node:|bun:|platform|http|filesystem/i.test(name))) throw new Error(`Engine native import: ${path}`);
  if (path.startsWith('packages/domain/') && imports.some((name) => /node:|bun:|platform|engine|adapter/.test(name))) throw new Error(`Domain native import: ${path}`);
}
const appSource = production.filter((path) => path.startsWith('apps/github-ingress/'));
const runtimeOwners = appSource.filter((path) => readFileSync(path, 'utf8').includes('ManagedRuntime.make'));
if (runtimeOwners.join() !== 'apps/github-ingress/src/composition.ts') throw new Error('Runtime owner changed');
for (const path of workspaces.slice(4)) {
  if (JSON.parse(readFileSync(`${path}/tsconfig.json`, 'utf8')).compilerOptions.skipLibCheck !== false) throw new Error('Strict library checking disabled');
}
const measurement = { base, tree: command('git', 'write-tree'), filesHash, lockHash, files, physicalEffect, rules: Object.fromEntries(rules), graph, runtimeOwners, rootOverride: root.overrides };
if (Bun.argv[2] === 'freeze') await Bun.write(`${out}/source.json`, JSON.stringify(measurement, null, 2) + '\n');
else {
  const frozen = JSON.parse(readFileSync(`${out}/source.json`, 'utf8'));
  if (filesHash !== frozen.filesHash || measurement.tree !== frozen.tree) throw new Error('Frozen source/tree changed');
  console.log(JSON.stringify(measurement, null, 2));
}
