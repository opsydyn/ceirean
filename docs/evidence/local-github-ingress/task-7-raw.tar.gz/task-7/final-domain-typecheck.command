moon run domain:typecheck --force --no-actions
