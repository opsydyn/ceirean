bun --no-env-file --no-install .superpowers/sdd/2026-10-20-local-github-ingress/task-7-measure.mjs verify
