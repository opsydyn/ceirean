#!/usr/bin/env bash
set -u
set -o pipefail

cd /private/tmp/leviathan-compatibility || exit 1
out=.superpowers/sdd/2026-10-20-local-github-ingress/controller-final-gates
mkdir -p "$out"

run() {
  local name="$1"
  shift
  printf '%q ' "$@" > "$out/$name.command"
  printf '\n' >> "$out/$name.command"
  printf 'Running %s\n' "$name"
  local status=0
  env -i PATH="$PATH" HOME="$HOME" TMPDIR="$TMPDIR" "$@" > "$out/$name.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$out/$name.exit"
  if [ "$status" -ne 0 ]; then
    printf 'Stopped: %s exited %s\n' "$name" "$status"
    tail -n 45 "$out/$name.log"
    return "$status"
  fi
  printf 'Passed %s\n' "$name"
}

run 00-head git rev-parse HEAD || exit $?
run 01-install bun install --frozen-lockfile --ignore-scripts || exit $?
run 02-check bun run check || exit $?
for project in domain engine probe github-admission github-adapter github-ingress; do
  run "$project-typecheck" moon run "$project:typecheck" --force --no-actions || exit $?
done
for project in domain engine probe github-admission github-adapter github-ingress; do
  run "$project-test" moon run "$project:test" --force --no-actions || exit $?
done
run 99-whitespace git diff --check || exit $?
printf 'All controller final gates passed.\n'
