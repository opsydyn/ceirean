**I1 Start policy binding: ADDRESSED.** `apps/github-ingress/src/composition.ts:173`
acquires ledger ownership, reads the validated active policy, and compares complete
`LocalIngressPolicy` schema equivalence before authority acquisition or listening.
Disagreement fails the scoped acquisition without installing policy. The check
does not sample admission clocks. `composition.ts:214` leaves configure/status
outside this equality requirement, so a different next policy remains installable.
`apps/github-ingress/tests/final-fix.test.ts:27` covers revision, same-revision
allowlist/identity/policy/profile disagreement, no API calls, unchanged ledger,
status under mismatch, matching-policy startup and ownership reacquisition.

**I2 Refused CLI exit: ADDRESSED.** `apps/github-ingress/src/cli.ts:13` preserves
the structured output and maps typed `Refused` to exitCode 1, other completed
outcomes to 0; `apps/github-ingress/src/main.ts:24` propagates that exitCode.
No refusal exception or output-envelope change was introduced.
`apps/github-ingress/tests/final-fix.test.ts:68` invokes the real CLI/main boundary
for AuthorityChanged, RevisionReused, CapacityExceeded and Installed, checking
the structured result and exit. Installed with a differing file policy succeeds,
also guarding I1's start-only placement. Existing print/dispose ownership remains.

**I3 Local status readout: ADDRESSED.**
`packages/github-adapter/src/live-sqlite-storage.ts:50` defines schema-derived
local projections; :348 returns current policy, bounded policy history and
decision-key/operator/revision/time/decision/provenance facts. Live provenance
contains the normalized permission observation, not a token, raw response,
receipt digest or reusable monotonic lease. Both arrays are capped at 256.
Projection occurs after existing row/evidence validation inside the same read-only
snapshot transaction (:370), without a public route or ownership acquisition.
`apps/github-ingress/tests/final-fix.test.ts:134` covers admitted, local-denied and
live-denied histories while the listener owns storage, unchanged database bytes,
secret/raw-field exclusions, unchanged public projection, no public status route
and corrupt-evidence refusal. Status is allowed with a differing file policy.

**M1 Memory receipt metadata: ADDRESSED.**
`packages/engine/tests/memory-live-inbox.ts:102` preserves a known receipt instead
of overwriting its display metadata; conflict/capacity checks still precede this
branch and absent receipts still insert. `packages/engine/tests/live-admission.test.ts:71`
checks original receipts and records remain unchanged on fact-equivalent rename
replay, with only the original authority call.

**M2 Fresh paired law: ADDRESSED.**
`packages/engine/tests/live-admission-properties.test.ts:84` builds histories
containing repeated identical deliveries and alternate delivery IDs, then runs
opposite orders against two independently empty stores (:93, :126). It checks
fresh previews, duplicate outcomes, one authority call per command and distinct
receipt counts. Command-key sorting and consistent decision/evidence identity
normalization (:64) permit comparison without incidental order-dependent IDs.
There is no pre-admitted priming. Existing law registration, seeds and primary
case budgets are retained; this closes coverage, not a claimed production bug.

**M3 Newline readiness: ADDRESSED.**
`packages/github-adapter/tests/readiness.ts:9` accumulates bytes through newline
with a 4096-byte ceiling, EOF refusal, fatal UTF-8 decoding and a five-second
watchdog. The named app readers now use it at
`apps/github-ingress/tests/restart.test.ts:144`, :441 and :495; both named adapter
readers use it too. Exact readiness/phase assertions remain, as do the existing
parent phase watchdog and workspace timeouts. `packages/github-adapter/tests/readiness.test.ts:18`
covers split JSON and UTF-8, EOF, overflow and a short synthetic watchdog.
No retry or timeout increase was introduced.

**M4 Outer archive metadata: ADDRESSED.**
`docs/evidence/local-github-ingress/final-fix/qualify.py:150` writes payload-only
USTAR; :168 checks full regular-member set equality, unique names, byte lengths,
hashes and absence of AppleDouble/PAX metadata. Actual outer archives matched
their indices with 212 historical, 154 original Task 7, four original docs,
132 final-fix raw and two final-fix docs members; no unexpected regular or
metadata members were found. Original historical payload hashes are preserved.
`docs/evidence/local-github-ingress/final-fix/archive-repackaging.json:8` explicitly
records the nested Task 6 historical exception: unchanged SHA256
`7d9b86923cfc50b4115830ac81dce45afcd30bdabb0bf212da9142910a50f734`,
56 regular members, 28 AppleDouble entries and 28 PAX-bearing payload members.
Those values were independently read and confirmed; nested metadata freedom is
not claimed. The chosen lossless-outer fix satisfies the finding without rewriting
the nested historical evidence.

### Checks

- Check: personally reviewed the supplied `review-36de5ba..7131d59.diff` fix
  package, canonical final-fix report and ledger. Scope was I1-I3/M1-M4 and new
  breakage in their production/test/tooling/documentation changes, not a new
  whole-branch review. No agents or Git commands were invoked.
- Check: read-only artifact verification matched all 169 current source/config
  files to the frozen inventory and recomputed inventory SHA256
  `83db0a82dc238faaf906a26c33962eb460ba9d82b8dc65042b8304a69dc459c2`.
  The manifest binds source `5e531ae60f7f11e91310e24965e2a74805d4d173` and tree
  `42f3d7af0bcc7b3716e1adf8081373d45ffc5899`; the documentation package is
  `7131d59`, separate from tested source. Qualification tooling is independently
  hashed rather than folded into a self-referential source inventory.
- Check: verified all 16 recorded gate log hashes, exit files and source bindings;
  parsed the six raw suite summaries and matched 935 tests, zero failures and
  8995 assertions. The record includes all six typechecks. These are inspected
  existing run outputs, not reviewer-executed tests or the parent's final gates.
- Check: verified five new-source control triples, both RED log hashes/exits,
  mutation identity, restored GREEN identity and source/test binding JSON.
  Read their intended failing assertions and successful restoration outputs;
  no old b7 source binding was substituted. No control was rerun or counted as
  a primary law. Recorded budgets remain 24000 new and 168000 legacy cases.
- Check: inspected meaningful I1/I3 assertion REDs, the separate I2 expected-1 /
  actual-0 RED, M1 metadata RED and covering GREEN/full-suite outputs. The new
  I1-I3 file records 15 passing tests / 92 assertions; readiness tests are present
  in the adapter output, and the paired law is present in engine output.
  Nonqualifying SQLite-open, missing-helper and normalization development failures
  remain classified as such in the ledger, not substituted for behavioral REDs.
- Check: read-only outer archive/header/index/hash verification and the nested
  exception inspection passed. The historical b7 manifest retains SHA256
  `52e1613f41e93eedd7db2b807b8b1b58cb7a3daba154ac70c0377bde3e03666d`;
  historical qualification is not relabelled as evidence for changed source.
- Check: no concrete behavioral doubt remained unanswered by code and recorded
  covering runs, so no focused test or full suite/gate was run. No install,
  network/API/listener/tunnel, real credential, source edit, Git mutation, push
  or merge occurred. Only this ignored rereview file was written via apply_patch.

### New Breakage In The Fix Diff

None identified: no new Critical, Important or Minor finding.

### Out-of-Scope Observations

None newly raised. The ledger preserves the controller-accepted Moon/no-upgrade
disposition, Task 5 initial RED-history gap, Task 6 summary-versus-raw distinction
and all 11 prior Declined To Judge boundaries. These remain evidence/scope limits,
not runtime waivers or live approval; this rereview does not reopen them.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.**
I1, I2, I3, M1, M2, M3 and M4 are closed for this scoped rereview. The parent still
owns the requested fresh final gate block, archive closure and integration
decision. This verdict does not assert those later steps completed and grants
no merge, push, deployment or live rehearsal approval.
