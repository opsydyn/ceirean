import { allRules } from '@opsydyn/oxlint-effect';
import config from '../../../oxlint.config.ts';

const root = '/private/tmp/leviathan-compatibility';
const directory = `${root}/.superpowers/sdd/2026-10-20-local-github-ingress/controller-final-gates`;
const source = await Bun.file(`${root}/docs/evidence/local-github-ingress/final-fix/source.json`).json();
const manifest = await Bun.file(`${root}/docs/evidence/local-github-ingress.json`).json();
function requireTrue(condition, message) {
  if (!condition) throw new Error(message);
}
async function hash(path) {
  return new Bun.CryptoHasher('sha256').update(await Bun.file(path).arrayBuffer()).digest('hex');
}
for (const [path, expected] of Object.entries(source.files)) {
  requireTrue(await hash(`${root}/${path}`) === expected, `Source mismatch: ${path}`);
}
requireTrue(source.filesHash === manifest.localQualification.source.filesHash, 'Manifest source mismatch');
requireTrue(await hash(`${root}/bun.lock`) === source.lockHash, 'Lock mismatch');
const patches = {
  'patches/@flue%2Fruntime@2.3.0.patch': '07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a',
  'patches/gaxios@7.3.1.patch': '7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e',
};
for (const [path, expected] of Object.entries(patches)) {
  requireTrue(await hash(`${root}/${path}`) === expected, `Patch mismatch: ${path}`);
}
const rules = Object.keys(allRules);
requireTrue(rules.length === 141, 'Effect rule count changed');
for (const rule of rules) {
  const setting = config.rules[rule];
  requireTrue((Array.isArray(setting) ? setting[0] : setting) === 'error', `Rule weakened: ${rule}`);
}
const paths = {
  domain: 'packages/domain',
  engine: 'packages/engine',
  probe: 'probes/bun-effect-flue',
  'github-admission': 'probes/github-admission',
  'github-adapter': 'packages/github-adapter',
  'github-ingress': 'apps/github-ingress',
};
const resolutions = Object.fromEntries(Object.entries(paths).map(([name, path]) => [
  name, Bun.resolveSync('effect', `${root}/${path}`),
]));
requireTrue(new Set(Object.values(resolutions)).size === 1, 'Multiple physical Effect resolutions');
const packageJson = await Bun.file(`${root}/package.json`).json();
requireTrue(packageJson.overrides['@effect/platform-node-shared'] === '4.0.5', 'Platform override changed');
const gateNames = ['00-head', '01-install', '02-check', ...Object.keys(paths).map((x) => `${x}-typecheck`),
  ...Object.keys(paths).map((x) => `${x}-test`), '99-whitespace'];
const gates = [];
for (const name of gateNames) {
  const exit = Number((await Bun.file(`${directory}/${name}.exit`).text()).trim());
  requireTrue(exit === 0, `Gate failed: ${name}`);
  gates.push({ name, exit, logHash: await hash(`${directory}/${name}.log`) });
}
const suites = [];
for (const [name] of Object.entries(paths)) {
  const log = await Bun.file(`${directory}/${name}-test.log`).text();
  const passed = Number(log.match(/(?:^|\n)\s*(\d+) pass\b/)?.[1]);
  const failed = Number(log.match(/(?:^|\n)\s*(\d+) fail\b/)?.[1]);
  const assertions = Number(log.match(/(?:^|\n)\s*(\d+) expect\(\) calls\b/)?.[1]);
  const expected = manifest.localQualification.suites.find((value) => value.workspace === name);
  requireTrue(expected && passed === expected.passed && failed === 0 && assertions === expected.assertions,
    `Unexpected suite result: ${name}`);
  suites.push({ workspace: name, passed, failed, assertions });
}
const output = {
  verifiedHead: (await Bun.file(`${directory}/00-head.log`).text()).trim(),
  testedSource: manifest.localQualification.source,
  sourceFiles: Object.keys(source.files).length,
  effectRules: rules.length,
  resolutions,
  gates,
  suites,
  totals: suites.reduce((sum, value) => ({
    passed: sum.passed + value.passed,
    failed: sum.failed + value.failed,
    assertions: sum.assertions + value.assertions,
  }), { passed: 0, failed: 0, assertions: 0 }),
  liveQualified: false,
};
await Bun.write(`${directory}/controller-verification.json`, `${JSON.stringify(output, null, 2)}\n`);
console.log(JSON.stringify(output, null, 2));
