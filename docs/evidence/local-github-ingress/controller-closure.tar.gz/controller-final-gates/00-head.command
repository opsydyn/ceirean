git rev-parse HEAD 
