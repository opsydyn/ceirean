moon run github-adapter:typecheck --force --no-actions 
