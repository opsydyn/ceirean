moon run engine:test --force --no-actions 
