moon run probe:typecheck --force --no-actions 
