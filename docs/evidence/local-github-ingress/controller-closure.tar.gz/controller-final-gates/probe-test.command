moon run probe:test --force --no-actions 
