bun run check 
