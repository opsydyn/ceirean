bun install --frozen-lockfile --ignore-scripts 
