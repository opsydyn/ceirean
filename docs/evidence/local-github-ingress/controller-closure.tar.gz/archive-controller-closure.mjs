const root = '/private/tmp/leviathan-compatibility';
const scratch = `${root}/.superpowers/sdd/2026-10-20-local-github-ingress`;
const destination = `${root}/docs/evidence/local-github-ingress`;
const names = [
  'progress.md', 'task-7-review.md', 'final-review.md', 'final-rereview.md',
  'run-controller-final-gates.sh', 'controller-final-audit.mjs',
  'archive-controller-closure.mjs',
];
for await (const name of new Bun.Glob('controller-final-gates/*').scan({ cwd: scratch, onlyFiles: true })) {
  names.push(name);
}
names.sort();
const members = [];
for (const name of names) {
  const bytes = await Bun.file(`${scratch}/${name}`).arrayBuffer();
  members.push({ name, bytes: bytes.byteLength,
    sha256: new Bun.CryptoHasher('sha256').update(bytes).digest('hex') });
}
const archive = `${destination}/controller-closure.tar.gz`;
const packed = Bun.spawnSync({
  cmd: ['/usr/bin/tar', '--format=ustar', '--no-mac-metadata', '--no-xattrs',
    '-czf', archive, '-C', scratch, ...names],
  env: { COPYFILE_DISABLE: '1' },
  stdout: 'pipe', stderr: 'pipe',
});
if (packed.exitCode !== 0) throw new Error(new TextDecoder().decode(packed.stderr));
const archiveHash = new Bun.CryptoHasher('sha256')
  .update(await Bun.file(archive).arrayBuffer()).digest('hex');
const index = `${destination}/controller-closure-index.json`;
await Bun.write(index, `${JSON.stringify({ archive: 'controller-closure.tar.gz',
  sha256: archiveHash, payloadOnly: true, members }, null, 2)}\n`);
const checker = `import hashlib,json,sys,tarfile
index=json.load(open(sys.argv[1]))
expected={x['name']:x for x in index['members']}
with tarfile.open(sys.argv[2]) as archive:
    actual=archive.getmembers()
    assert len(actual)==len(expected)
    assert {x.name for x in actual}==set(expected)
    for item in actual:
        assert item.isfile() and not item.pax_headers
        assert not any(x.startswith('._') for x in item.name.split('/'))
        data=archive.extractfile(item).read()
        assert len(data)==expected[item.name]['bytes']
        assert hashlib.sha256(data).hexdigest()==expected[item.name]['sha256']
print(json.dumps({'verifiedMembers':len(expected),'unexpectedMembers':0}))
`;
const checked = Bun.spawnSync({ cmd: ['python3', '-c', checker, index, archive],
  stdout: 'pipe', stderr: 'pipe' });
if (checked.exitCode !== 0) throw new Error(new TextDecoder().decode(checked.stderr));
const progress = await Bun.file(`${scratch}/progress.md`).text();
const rulings = progress.split('\n').filter((line) => line.startsWith('Ruling:'));
await Bun.write(`${destination}/controller-rulings.md`,
  `# Final Controller Rulings\n\nExact decisions and costs from the controller recovery ledger.\n\n${rulings.join('\n\n')}\n`);
await Bun.write(`${destination}/controller-verification.json`,
  await Bun.file(`${scratch}/controller-final-gates/controller-verification.json`).arrayBuffer());
console.log(JSON.stringify({ archiveHash, members: members.length, rulings: rulings.length,
  archiveVerification: JSON.parse(new TextDecoder().decode(checked.stdout)) }, null, 2));
