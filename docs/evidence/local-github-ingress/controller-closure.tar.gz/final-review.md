# Whole-Branch Review: Local GitHub Ingress

## Scope And Identity

Personal review, no subagents. Reviewed the actual checkout
`/private/tmp/leviathan-compatibility`, branch `codex/local-github-ingress`, from
`4fdf876987668ea61bab1be30e5d04c48f0515e0` to
`36de5ba28e8921952c26a2fb6e7c9728bd305a3d` (12 commits, 72 net changed files).
HEAD and clean tracked status were verified. The supplied 644846-byte diff has
SHA256 `7415e9c38aaea3aae70317cc037cc345f57b1c512d4f5e2654c5810f381ecb26`.

Read the binding spec, plan, extracted context, canonical runbook, execution
decisions, assessment, measured manifest and Task 7 report. Used the supplied
diff as the change map and inspected complete current production/test files in
bounded reads, including their middle sections. Coverage includes:

- All app CLI/config/composition/listener/main/response/report source, every app
  test, synthetic fixture and recovery child.
- Both new domain modules and both domain test files; all new engine factories,
  ports, service/errors, tests, laws and memory driver; existing command identity
  schemas and fact-equivalence helper at the integration boundary.
- Every adapter source and test file, including native HTTP/key ownership,
  protocol capture/verification, path policy, SQLite schema/transactions,
  native race/capacity/recovery tests and strict compatibility tests.
- All three legacy probe extraction diffs, barrel exports, workspace manifests,
  Moon/TypeScript configuration and lock delta. Documentation/evidence changes
  were reviewed for claims and source boundaries, not treated as executable proof.

No source edits, Git mutation, alternate checkout, install, suite/full-gate rerun,
network/API access, listening socket, real key, tunnel, publication or merge.
Only this ignored review file was written in the checkout. One explicitly
permitted focused in-process check used temporary synthetic state, described
under I1. Archive inspection was read-only; no archive-wide hash/control rerun.

## Strengths

- Replay is genuinely first, including changed-digest and command-fact conflicts;
  immutable per-decision evidence is not installed as shared current authority.
  SQLite rechecks replay, policy, provenance and both clocks before committing,
  with a final post-write expiry barrier and rollback of staged keys.
- Native authority separates finite outcomes from actual settlement. Timed-out
  fetches/readers remain owned, four native slots stay bounded, disposal closes
  admission synchronously, and main owns the truthful ten-second failed exit.
  Tests exercise abort-ignoring fetches and delayed/rejected reader cancellation.
- Scope boundaries are disciplined: pure domain, inferred engine services, native
  adapter, one application runtime, no execution/publication path, and no new
  lint waiver or cohort escape. Legacy protocol extraction preserves its wrapper's
  distinct reply decoding/status behavior.
- Recovery and evidence claims distinguish local synthetic observations from
  live grants, host durability and exactly-once execution. Controls retain their
  unsuccessful initial selections rather than presenting them as qualifying REDs.

## Issues

### Critical

None identified.

### Important: Fix Before Merge

#### I1 [P1] Start accepts a configuration that disagrees with the active ledger policy

**Location:** `apps/github-ingress/src/composition.ts:173` (also :129, :177;
`packages/github-adapter/src/live-sqlite-inbox.ts:514`).

Start passes the file policy as `initialPolicy`, opens the ledger, then proceeds
without comparing the active stored policy with that file policy. `initialPolicy`
is consumed by initialization, not validated against the active policy on open.
Admission subsequently loads the SQLite policy, while the App signer uses the
file's appId. Thus this is not merely harmless duplicate configuration.

**Observed:** initialize local-1 with allowed operator 66; change the explicit
config to local-2 allowing only 67, without successfully configuring the ledger;
open the start application and deliver a fresh signed command from 66. Startup
succeeded; the response was HTTP 200 / `Recorded`, with five synthetic API calls.
No network or listener was involved. The check exited 0 and disposed the runtime
and scoped temporary files. It was the only behavioral check run: current tests
cover decoding and successful/refused configure, but not this startup mismatch.

**Requirement/expectation:** spec :189-192 requires normal startup to validate
scope and configuration. Requiring an explicit configure operation does not
permit silently starting with a different policy after that step was missed or
refused. A reasonable operator expects either their reviewed config to be active
or startup to fail, particularly after removing an operator or disabling a profile.

**Fix:** in the start acquisition only, after taking ledger ownership and before
listening, compare the complete stored LocalIngressPolicy with the validated
file policy, including revision and all identity/allowlist/profile fields. Refuse
disagreement without mutation, and unwind ownership. Do not add this equality
precondition to configure, which intentionally supplies a different next policy.
Add mismatched revision and same-revision/different-content regressions plus a
matching-policy success and failed-start reacquisition control.

#### I2 [P2] A refused configure command exits successfully

**Location:** `apps/github-ingress/src/main.ts:26`;
`apps/github-ingress/src/cli.ts:14`;
`apps/github-ingress/src/composition.ts:209`.

`updatePolicy` returns successful Result values containing `Refused` for stale
expected revision, reused revision or capacity. The CLI prints that value and
returns `kind: Completed`; main unconditionally maps Completed to exit 0. The
existing CLI test explicitly exercises `Refused`, but checks only its output.

**Impact/expectation:** a shell/operator workflow using `configure ... && start ...`
continues after no policy was installed. This compounds I1 today, but remains a
misleading failed administrative command even after I1 is fixed. An ordinary CLI
caller should not have to parse success-channel JSON to discover that its change
was refused. This is a reasonable-user requirement, not an explicit exit-code
sentence in the spec.

**Fix:** preserve the structured refusal, but propagate a nonzero command exit
for Refused, while Installed/init/status remain successful. Keep refusal as a
typed domain outcome rather than inventing an unstructured native exception.
Test the main/CLI boundary for all three refusal reasons and success.

#### I3 [P2] Local status discards the promised decision and evidence readout

**Location:** `packages/github-adapter/src/live-sqlite-storage.ts:317`;
`packages/github-adapter/src/live-sqlite-inbox.ts:549`.

The validated status result contains only four counts, current revision, wall
floor and scope. Although validation reads policies, records and immutable
evidence, none of those outcomes or evidence facts are returned. The CLI merely
prints that result. There is no other local inspection command.

**Requirement/impact:** spec :197-199 requires counts and structured outcomes;
:265-267 keeps permission evidence, policy details and operator lists in local
status rather than public responses. The runbook directs the operator to inspect
sanitized status on refusal and to record observed admission/revocation evidence.
Counts alone cannot distinguish an admitted preview from a local or live-checked
denial, or identify the policy/operator/evidence bound to a historical outcome.
This is an incomplete operator workflow, not a request for a public admin route.

**Fix:** return bounded, schema-derived local policy and decision/evidence
projections from the same validated read-only snapshot. Include decision identity,
decision/reason, provenance, relevant revisions and minimal permission observation
facts; exclude secrets, tokens and raw bodies. Cover admitted, local-refused and
live-refused histories, plus active-owner read-only status and corrupt-row refusal.

### Minor: Explicit Final Triage

#### M1 [P3] Task 3 M1: memory inbox overwrites known receipt display metadata

**Location:** `packages/engine/tests/memory-live-inbox.ts:87`.

Duplicate lookup always sets the receipt, including an already known delivery.
Fact-equivalent input with different display names therefore replaces the original
receipt metadata. Native SQLite correctly inserts only for an unknown delivery
(`live-sqlite-inbox.ts:261`). No production authorization or evidence overwrite was
found; this is test-double drift and can conceal receipt immutability assertions.
**Recommendation: fix** the helper to retain a known receipt and add a metadata
preservation assertion. A controller-approved deferral is low risk, not implicit.

#### M2 [P3] Task 3 M2: permutation law does not compare fresh admission histories

**Location:** `packages/engine/tests/live-admission-properties.test.ts:64`.

The law first admits every unique command, then reverses only deliveries of those
already admitted commands. It establishes replay deduplication without authority
calls, not order invariance of two fresh histories containing duplicates. The
24000-case accounting is still correct; its semantic coverage is narrower than
the law's name and planned promise. Native deterministic race tests provide useful
separate coverage, so this is not proof of a production ordering defect.
**Recommendation: fix** the law using paired fresh stores and equivalent reordered
histories; compare normalized business outcomes by command key, not incidental
decision IDs/evidence UUIDs. Preserve the admitted cases and existing law budgets.
Any deferral must retain this coverage limitation explicitly.

#### M3 [P3] Task 7 M1: child phase parsing assumes stream chunks are messages

**Location:** `apps/github-ingress/tests/restart.test.ts:495` (also :143, :441;
`packages/github-adapter/tests/local-state.test.ts:257` and
`packages/github-adapter/tests/live-sqlite-inbox.test.ts:70` have related readiness reads).

A single stdout read need not contain a complete JSON line/sentinel; pipes may
split writes. The new recovery test decodes its first chunk as a whole JSON value.
This can make valid recovery behavior fail qualification intermittently. It does
not establish false successful recovery: the phase assertion precedes acceptance.
**Recommendation: fix** with a bounded newline accumulator that handles EOF and
split chunks, retaining the parent watchdog and exact phase assertions. Do not
raise timeouts or retry flaky gates unchanged.

#### M4 [P3] Task 7 M2: archives include unindexed AppleDouble metadata

**Location:** `docs/evidence/local-github-ingress/accepted-tasks-1-6-index.json:5`;
`docs/evidence/local-github-ingress/task-7-raw-index.json:5`.

Read-only tar-header inspection found 424 regular members in the historical
archive: 212 indexed data members plus 212 unindexed AppleDouble entries. Task 7
has 310: 154 indexed data members plus 156 AppleDouble entries, including directory
metadata. Every unindexed entry has an `._` basename, AppleDouble magic and size
163 bytes. macOS tar's ordinary listing hid them; a standard tar parser exposed
them. No unindexed production source or extra gate evidence was found.

Whole-archive hashes bind these bytes, so this does not invalidate the selected
member comparisons or the passing controls. It does weaken a claim of an entirely
enumerated, metadata-free portable evidence package. **Recommendation: fix** the
packaging to suppress Apple metadata and assert no unexpected regular members,
then update only affected archive identities/indices and documentation checks.
Alternatively explicitly document/index this metadata with controller approval;
do not silently call 154/212 the complete regular-member counts.

## Requirements Fit And Evidence Judgment

The production architecture substantially fits the approved slice and controller
rulings: native `{ driver, dispose }`, one runtime, finite outcomes versus tracked
cleanup, nonzero forced shutdown, strict external canonical storage, explicit
operator-declared custom roots, no second environment-JSON channel, and PKCS#8-only
SDK import are all represented. No new dependency cohort, manual Effect/Layer
channels, helper provisioning, Node controller, permission cache, second runtime,
execution or publication path was identified in the branch changes.

The unresolved requirements are startup config binding (I1), honest administrative
exit behavior (I2, reasonable-user expectation), local outcome inspection (I3),
and the narrower property-law promise (M2). Nothing in execution-decisions.md
waives these. Path locality remains an operator declaration under the explicit
ruling, not an inferred filesystem guarantee.

The recorded six typechecks and 903-to-916 full-gate progression are existing
source-bound evidence, not tests run by this reviewer. The measured final source
commit resolves to the stated tree `9ecbfc4977ef3899c70b0e6ac18029c60a83b6e8`.
Git comparison from `b7f5d4e` to reviewed HEAD contains only documentation/evidence
and approved scratch relocation, not changed production/tests/configuration.
Current lock SHA256 matches `8cb4d58bd88280daee28101e542cd9b7120ec7ee63dd5094daf59c2a45fddf59`.
Thus later docs do not invalidate the source inventory linkage. I did not repeat
the Task 7 reviewer's independent 166-file and archive/control hash audit.

The manifest reports 916 tests, 8893 assertions, 24000 new primary law cases,
168000 legacy primary cases, and five controls each with two intended REDs and
exact restoration/GREEN. Its validator is appropriately described as supplied
data consistency validation, not attestation. Passing gates do not answer the
missing cross-boundary I1 case demonstrated above.

Other required triage decisions:

- **Moon update notices:** defer/no upgrade. `.prototools` still pins Moon 2.5.4;
  lint/toolchain config is unchanged. Preserved advertisements are not lint
  warnings, tool upgrades, or a reason to rerun successful suites.
- **Initial Task 5 TDD history:** retain the disclosed process-evidence gap.
  Later behavior/control/full-gate evidence cannot recreate an earlier RED.
  No production defect follows solely from that gap. Recommend controller
  acceptance of this historical limitation, not a retrospective TDD claim.
- **Task 6 TDD excerpts:** retain their summary-only classification; use the
  separately archived raw logs for gate claims. No duplicate gate run recommended.
- **Task 6 late-key/bind gap:** closed in current Task 7 source by
  `apps/github-ingress/tests/restart.test.ts:575`; it checks invalid-key unwind,
  occupied-port failure, unchanged ledger and subsequent acquisition/listen.
  This closure does not cover I1 or I2.
- **Historical pending-review prose:** the candidate docs predate the user's
  confirmation that all seven task reviews were accepted. Preserve their original
  scope; eventual controller status reconciliation must not imply this final
  review accepted the branch. No runtime risk or new waiver is inferred.

## Recommendations

Use the authorized single final fix wave for I1-I3 and bounded regressions. M1-M4
are small, relevant cleanup/qualification changes worth including; otherwise
obtain an explicit controller disposition for each. Keep the policy comparison
start-only, preserve stopped-ingress configure and native ownership, and do not
broaden dependencies, grants, budgets or runtime architecture.

Request scoped rereview of those diffs and their cross-boundary regressions,
with honest source/evidence rebinding for any changed code. Do not present the
existing b7f5d4e gates as gates for a future fix commit. This report neither runs
nor authorizes another broad qualification pass or any live action.

## Declined To Judge

Every behavior considered but set aside is listed explicitly; these are scope
or evidence boundaries, not implied waivers. Controller rulings remain required.

- Actual GitHub endpoint/API-version/token/grant compatibility, including the
  metadata-only permission-read sequence: synthetic checks cannot prove real
  selected-installation grants; network/live access was forbidden in this review.
- Real credential custody, actual App/private-key validity and operator PKCS#1
  conversion: no real keys were authorized; only the synthetic PKCS#8 contract
  and native validation code were reviewed.
- Public tunnel TLS/routing/provider lifecycle and end-to-end response latency:
  operator-owned, exact-target live approval remains absent; no tunnel was run.
- Mechanical detection of arbitrary network mounts, external build roots and
  third-party sync software: the canonical controller ruling explicitly makes
  locality an operator declaration; conventional path checks were still reviewed.
- Protection against a malicious same-UID process replacing files or rolling
  state back in place: excluded by the documented local operator trust boundary;
  no cryptographic anti-rollback or adversarial same-UID claim is accepted.
- Automatic enforcement of config-file mode and operator setup/conversion steps:
  the runbook expressly requires these operationally and discloses the config
  reader's mode limitation; it is not claimed as an implemented credential check.
- Host/power/disk-loss recovery, portable backup migration and unattended
  production availability: process-death tests do not establish those deferred
  storage/operations guarantees; old-snapshot replay loss remains explicit.
- Immediate atomic permission revocation across GitHub and SQLite: explicitly
  impossible in this design; observation intervals and future reauthorization
  are required, rather than a claim of immediate or execution authority.
- Execution/models/workers, assessment output, GitHub comment/PR writes,
  discovery/multi-repository operation, scheduling and cloud deployment: absent
  from and forbidden by this admission-preview slice, not missing implementation.
- Disk-byte retention quotas, automatic pruning, reset and replay-key migration:
  intentionally deferred; row ceilings and no automatic key loss were reviewed.
- A new independent upstream artifact download/install or repeat of all historical
  gates/archives: expressly disallowed; existing independently audited evidence
  was judged for identity and claim scope, not relabelled as a fresh rerun.

## Assessment

**Ready to merge? No.** I1 is a reproduced authorization-configuration failure;
I2 and I3 leave unsafe/missing operator behavior despite strong core replay and
cleanup work. Fix these in the bounded final wave, explicitly dispose of every
minor/process item, and obtain scoped rereview. Task acceptance and recorded
green gates do not predetermine whole-branch acceptance. No merge, push or live
rehearsal is authorized by this review.
