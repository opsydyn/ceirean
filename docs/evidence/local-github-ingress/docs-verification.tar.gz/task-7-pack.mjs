import { readFileSync, readdirSync, mkdirSync, renameSync } from 'node:fs';
const canonical = 'docs/evidence/local-github-ingress';
const scratch = '.superpowers/sdd/2026-10-20-local-github-ingress/task-7-raw';
const hash = (bytes) => new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
function entries(path) {
  return readdirSync(`${canonical}/${path}`, { withFileTypes: true }).flatMap((entry) => {
    const name = `${path}/${entry.name}`;
    return entry.isDirectory() ? entries(name) : [name];
  });
}
const paths = entries('task-7').sort();
const members = paths.map((path) => { const bytes = readFileSync(`${canonical}/${path}`); return { path, bytes: bytes.length, sha256: hash(bytes) }; });
const archive = `${canonical}/task-7-raw.tar.gz`;
const result = Bun.spawnSync(['tar', '-czf', `${process.cwd()}/${archive}`, '-C', canonical, 'task-7']);
if (result.exitCode !== 0) throw new Error(result.stderr.toString());
for (const member of members) {
  const extracted = Bun.spawnSync(['tar', '-xOf', archive, member.path]);
  if (extracted.exitCode !== 0 || !extracted.stdout.equals(readFileSync(`${canonical}/${member.path}`))) throw new Error(`Archive mismatch: ${member.path}`);
}
await Bun.write(`${canonical}/task-7-raw-index.json`, JSON.stringify({ archive, sha256: hash(readFileSync(archive)), byteCompared: members.length, members }, null, 2) + '\n');
// Retain originals in ignored scratch, except the independently readable source inventory.
mkdirSync(scratch, { recursive: true });
for (const entry of readdirSync(`${canonical}/task-7`)) {
  if (entry !== 'source.json') renameSync(`${canonical}/task-7/${entry}`, `${scratch}/${entry}`);
}
console.log(`Compared ${members.length}/${members.length} raw members; originals retained in ${scratch}`);
