import { readFileSync, existsSync } from 'node:fs';
import { validateLocalQualification } from '../../../apps/github-ingress/src/qualification-report.ts';
import { Result } from '../../../apps/github-ingress/node_modules/effect/dist/index.js';
const canonical = 'docs/evidence/local-github-ingress';
const scratch = '.superpowers/sdd/2026-10-20-local-github-ingress';
const json = (path) => JSON.parse(readFileSync(path, 'utf8'));
const hash = (bytes) => new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
function git(...args) {
  const result = Bun.spawnSync(['git', ...args]);
  if (result.exitCode !== 0) throw new Error(result.stderr.toString());
  return result.stdout.toString().trim();
}
const manifest = json('docs/evidence/local-github-ingress.json');
const measured = Result.getOrThrow(validateLocalQualification(manifest.localQualification));
const source = json(`${canonical}/task-7/source.json`);
if (git('rev-parse', `${measured.source.commit}^{tree}`) !== source.tree || measured.source.tree !== source.tree) throw new Error('Tested tree mismatch');
for (const [path, expected] of Object.entries(source.files)) {
  if (hash(readFileSync(path)) !== expected) throw new Error(`Source drift: ${path}`);
}
const history = json(`${canonical}/accepted-tasks-1-6-index.json`);
const rawIndex = json(`${canonical}/task-7-raw-index.json`);
function extract(archive, path) {
  const result = Bun.spawnSync(['tar', '-xOf', archive, path]);
  if (result.exitCode !== 0) throw new Error(`Cannot extract ${path}`);
  return result.stdout;
}
for (const index of [history, rawIndex]) {
  if (hash(readFileSync(index.archive)) !== index.sha256 || index.byteCompared !== index.members.length) throw new Error('Archive identity mismatch');
  for (const member of index.members) {
    const bytes = extract(index.archive, member.path);
    if (bytes.length !== member.bytes || hash(bytes) !== member.sha256) throw new Error(`Archive member mismatch: ${member.path}`);
    const original = index === history ? `${scratch}/${member.path}` : member.path === 'task-7/source.json' ? `${canonical}/${member.path}` : `${scratch}/task-7-raw/${member.path.slice(7)}`;
    if (!bytes.equals(readFileSync(original))) throw new Error(`Original byte mismatch: ${member.path}`);
  }
}
if (manifest.rawLogs.sha256 !== rawIndex.sha256 || manifest.historicalArchive.sha256 !== history.sha256) throw new Error('Manifest archive binding mismatch');
for (const gate of measured.gates) {
  const name = `final-${gate.id.replace(':', '-')}`;
  if (hash(extract(rawIndex.archive, `task-7/${name}.log`)) !== gate.logHash || Number(extract(rawIndex.archive, `task-7/${name}.exit`).toString()) !== gate.exit) throw new Error(`Gate mismatch: ${name}`);
}
for (const control of measured.controls) {
  const binding = manifest.controlBindings.find((entry) => entry.name === control.name);
  if (source.files[binding.path] !== control.beforeHash || source.files[binding.test] !== binding.testHash) throw new Error('Control source binding mismatch');
  const prefix = binding.logPrefix;
  for (const [offset, red] of control.red.entries()) {
    if (hash(extract(rawIndex.archive, `task-7/${prefix}-red-${offset + 1}.log`)) !== red.logHash) throw new Error('Control RED hash mismatch');
  }
  if (hash(extract(rawIndex.archive, `task-7/${prefix}-green.log`)) !== control.green.logHash) throw new Error('Control GREEN hash mismatch');
}
const removed = git('diff', '--cached', '--name-only', '--diff-filter=D').split('\n').filter(Boolean).sort();
if (JSON.stringify(removed) !== JSON.stringify([...history.trackedTask6Copies].sort()) || removed.some((path) => !existsSync(path))) throw new Error('Index-only relocation not exact');
const changed = git('diff', '--name-only', measured.source.commit).split('\n').filter(Boolean);
if (changed.some((path) => !path.startsWith('docs/') && !removed.includes(path) && !['README.md', 'apps/github-ingress/README.md'].includes(path))) throw new Error('Not a docs/evidence-only change');
console.log(JSON.stringify({ sourceCommit: measured.source.commit, sourceTree: source.tree, sourceFilesUnchanged: Object.keys(source.files).length, historicalMembersVerified: history.members.length, rawMembersVerified: rawIndex.members.length, removedTrackedCopies: removed, originalWorkingCopiesPreserved: true, totals: measured.totals, task7Review: manifest.review.task7, wholeBranchReview: manifest.review.wholeBranch }, null, 2));
