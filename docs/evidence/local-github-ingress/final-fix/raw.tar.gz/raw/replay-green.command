bun --no-env-file --no-install test packages/github-adapter/tests/live-sqlite-inbox.test.ts --timeout 30000 --test-name-pattern 'strict init/open'
