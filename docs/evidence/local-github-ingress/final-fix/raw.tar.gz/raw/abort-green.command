bun --no-env-file --no-install test apps/github-ingress/tests/listener.test.ts --timeout 30000 --test-name-pattern 'eight-second outcome'
