python3 docs/evidence/local-github-ingress/final-fix/qualify.py verify-source
