# Spec Compliance

- **Issues found.** The storage implementation covers the requested boundary, but the mandatory competing-writer/policy race proof is incomplete (Important I1 below).
- Reviewed personally, without agents: base `c973182f59d04d296e2c148024113b8e36127734`, head `17ed64a823485c3c6093d7119889a6c8d6ee818c`. Read the supplied 2,510-line / 102,308-byte diff once, in contiguous ranges 1-460, 461-920, 921-1380, 1381-1840, 1841-2300, 2301-2510. No middle omitted.
- **Cannot verify historical process:** the initial broad batch lacks clean behavioral RED history, as disclosed in `task-5-report.md` under Tests And TDD Evidence. Later regression history and passing tests cannot establish that earlier sequence. This is separate from the source/test findings below, not an invented runtime defect.
- **Evidence boundary:** the inspected author log `task-5-evidence/final-github-adapter-test.log` reports 194 pass / 0 fail, including the 25 storage/path cases. The report and `final-verification.json` claim 876 total. These are author-run evidence, not independently reproduced qualification. No test or gate reruns, git commands, network operations, listeners, or dependency changes were performed.

# Strengths

- Explicit storage export and create-disabled native connections; creation DDL is isolated from ordinary open (`packages/github-adapter/package.json:8`, `src/live-sqlite-inbox.ts`, functions `ownedDatabase`, `createSchema`, `acquireNative`; supplied diff lines 96-380). Failure cases compare unchanged ledger bytes; normal-open tests observe no DDL or journal transition (`tests/local-state.test.ts`, `firstCreationAndNoDdl`).
- Decision-local evidence, unique keys and receipt binding are checked together. Immediate transactions re-resolve replay; the final barrier rolls back the admission savepoint on refusal (`src/live-sqlite-inbox.ts`, `resolve`, `commit`; `src/live-sqlite-storage.ts`, `readRecord`, `readReceipt`). Exact capacity and rollback assertions exercise native SQLite rather than a mock (`tests/live-sqlite-inbox.test.ts`, `rollbackAndBusy`, `exactCapacities`; supplied diff lines 1381-1840).
- Native ownership is separate from the WAL ledger: rollback-journal `BEGIN EXCLUSIVE`, canonical file identity, strict scoped close, and real child-death/reopen tests (`src/live-sqlite-inbox.ts`, `holdOwner`; `tests/local-state.test.ts`, `ownedChildDeath`, `strictNativeClose`; supplied diff lines 2301-2510). No ledger transaction crosses network work.
- The documented production path policy accepts explicit custom roots, verifies owner-only root/descendants without requiring 0700 OS ancestors, rejects symlink components and known exclusions, and requires operator declaration rather than guessing arbitrary sync/network software (`src/local-state.ts:53`, `README.md:41`; synthetic custom-root acceptance test in `tests/local-state.test.ts:20`). Native production-filesystem acceptance is not claimed.

# Issues

## Critical

- None identified in this task-scoped review.

## Important

- **I1 - Missing required competing-writer proof.** `packages/github-adapter/tests/live-sqlite-inbox.test.ts`, `nativeInterleaving` (supplied `review-c973182..17ed64a.diff:1841-2083`): the second connection only begins and rolls back an immediate transaction. It never commits a competing decision/receipt or policy revision. Both operators subsequently use the same driver sequentially, and `updatePolicy` is also sequential on that driver. This proves Busy plus sequential conflict/stale-revision handling, not the brief's two-native-connection command/operator/policy race. Add deterministic interleavings in which another native writer actually commits the winning command/receipt and, separately, a policy revision after a draft was evaluated, before the driver commits. Assert duplicate/conflict or AuthorityChanged as appropriate, immutable winner evidence, and no losing receipt/evidence keys. Keep owner-exclusion tests separate; do not weaken ownership to enable this test. No production race bug is asserted solely from this coverage gap.
- **I2 - Duplicated security-sensitive barrier logic.** `packages/github-adapter/src/live-sqlite-inbox.ts:300-470`, `recordFresh.evaluate` and `finalizeFresh.evaluate` (supplied diff lines 381-625): both construct the same lease, recompute the decision and provenance eligibility, compare revision/clocks/decision, and map changed decisions through substantially repeated branches. The final pass has a legitimate additional floor (the earlier committed reading), but maintaining two copies of the shared validation creates avoidable drift risk at the final admission authority. Extract one synchronous validation routine parameterized by the relevant wall floor, and call it both before writes and at the final barrier; retain the second clock sample and savepoint rollback. This is the review rubric's Important duplicated-logic finding, not a request to remove either barrier or split into new runtime/service modules.

## Minor

- None added. Task 3 M1/M2 and pre-existing Moon notices remain for final triage, not findings against this diff.

# Checks And Limits

- **Named outside-diff risk:** storage delegates evidence/record correctness to unchanged domain schemas and `decideLiveAdmission`; a permissive contract could undermine the new final barrier and reopen validation. One focused contract inspection covered `packages/domain/src/live-admission.ts:143-208` and `packages/domain/src/live-admission-policy.ts:67-91`. These bind candidate/revision/permission facts, evaluation/start ordering, committed wall expiry, and request-local monotonic expiry. That doubt was resolved without a test run or broader crawl.
- Inspected the named author evidence files `final-verification.json`, `final-gates.sh`, and `final-github-adapter-test.log`; the adapter log contains passing native storage tests and no new warning finding. No independent claim about the other gate logs or actual commit/tree identity is made. The supplied c973 base is used; the reported initial 851 test-count misunderstanding is not treated as a base mismatch.
- Different HTTP ports and live application integration are not exercised here because this task introduces no listener. The guard's database-wide exclusion and actual child death are tested; Task 6/7 application qualification remains separate.
- Only this review file was written, via apply_patch.

# Assessment

**Spec compliance: Issues found.** Required two-writer/policy race evidence is missing; the inspected implementation otherwise follows the Task 5 storage boundary and controller path ruling.

**Task quality: Needs fixes.** Complete the deterministic native race proof and consolidate shared barrier validation while preserving both checks. Initial TDD history remains a disclosed, separately unverifiable process limitation, not disproved by the author's 876-test result.
