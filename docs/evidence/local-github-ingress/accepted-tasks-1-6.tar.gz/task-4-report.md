# Task 4 Report: Native GitHub Authority Adapter

Date: 2026-10-21 (Europe/London). Task/plan directory retains its original date.

## Status And Identities

- Task 4 only, implemented personally; no agents or reviewers dispatched.
- Checkout: `/private/tmp/leviathan-compatibility`.
- Branch: `codex/local-github-ingress`; no branch/worktree changes, merge or push.
- Starting clean HEAD: `450d5cf3c8c6b03863328345a55c6cf9114b5102`.
- Controller-approved source below that checkpoint: `f70706557b3988ec449c37a1d689a7b1fefc3f6c`.
- Final source commit: `929c30191ce522808f18feff425c6e98294daf58`, `feat: verify live GitHub admission authority`.
- Verified Git tree: `319cb114166c9c43c142a7fbc65821e707856334`; all final source SHA256s match the integrity audit. Final tracked working tree is clean on the required branch.
- Implemented, verified and committed; controller-owned independent review/acceptance remains pending. Report/evidence are retained in the existing ignored controller workspace, not added to the source commit.
- Read only Task 4 brief, binding context and relevant current interfaces/code; did not read the whole plan or prior task history. No redundant full prechange baseline.
- Controller ledger/review remain untouched. This is author verification, not independent approval.

## Changes

- `packages/github-adapter/src/github-auth.ts`: import PKCS#8 once during acquisition using jose `importPKCS8`; per-command `SignJWT` RS256, configured App ID issuer, `iat = floor(wallMs / 1000) - 60`, `exp = floor(wallMs / 1000) + 540`. Unsupported PKCS#1/malformed key acquisition returns finite `signing/InvalidKey` without HTTP.
- `src/github-http.ts`: native injected fetch, explicit composite signal, manual redirects, no retries, 2000 ms attempt deadline including response read, streamed 1048576-byte cap, fatal UTF-8 and Effect Schema JSON decoding. Headers include exact Accept/version plus fixed `Leviathan-Local-GitHub-Ingress` User-Agent. Every acquired reader is cancelled and released; cancellation is memoized, rejecting cancellation is observed, pending cancellation is awaited, and original read/status failure is retained if cleanup also fails.
- `src/github-authority.ts`: exported `makeGitHubAuthorityDriver` uses the actual `AuthorityQuery`, `LiveEvidenceLease`, `LiveAuthorityDriver` and `LiveAuthorityError` contracts. No invented Effect channel annotations, fake factories, new services or runtimes. Construction dependencies are captured before acquisition awaits; query facts are synchronously cloned before command awaits. A real engine authority-boundary test accepts the produced lease.
- Request-local six-second total deadline, first wall/monotonic observation before installation lookup, evidence lifetime at most six seconds from that observation and capped by token expiry. Wall/monotonic invalidity and expiry prevent follow-up requests. Monotonic start remains only in the ephemeral lease.
- Identity checks cover configured App/installation/account, nonsuspended installation, exactly one selected repository token with only metadata read, future token expiry, repository and owner IDs, archived/disabled refusal, canonical human user ID/type, permission response user ID. Only `permission: write|admin|read|none` is evidence; custom `role_name` is not authority. Read/none remain valid evidence for policy refusal, not an operational failure.
- `tests/github-authority.test.ts`: 145 synthetic adapter tests on final source. Tests use generated synthetic key material, recording fake fetch, explicit clocks and test-owned streams. No real credential read/conversion or App API traffic.
- Explicit package export: `./authority -> ./src/github-authority.ts`.

### Exact Dependency Delta

Controller clarified that workspace linkage is permitted, but no new external artifacts/cohort changes are allowed. Added exactly `"@leviathan/engine": "workspace:*"` to adapter `package.json` dependencies and the corresponding `workspaces["packages/github-adapter"].dependencies` field in `bun.lock`. No external artifact entry, version, integrity, root override or patch mapping changed. No undeclared transitive import is used.

- Previous lock SHA256: `13d9d8d647dc949b236108c7a5fc8a6d7798164583c5b4ed0d6c221af10e3e73`.
- Final lock SHA256: `d375b856e7760a67d0cf48ce683ee9d66ae14b75264c9cbe737ac1cf6bbe1de7`.
- Flue patch SHA256 unchanged: `07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a`.
- Gaxios patch SHA256 unchanged: `7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e`.
- Physical Effect resolution is the same `node_modules/.bun/effect@4.0.5/node_modules/effect/dist/index.js` in all five consumer workspaces. Root does not declare Effect and is not treated as a consumer.
- All 141 Effect rules remain error severity. Root override remains `@effect/platform-node-shared: 4.0.5`. Tool versions observed: Bun 1.4.2, Node v24.15.0 (tooling), Moon 2.5.4.

## Protocol Qualified Synthetically

Exactly these five requests per successful new command, with no token/permission cache:

1. GET `https://api.github.com/app/installations/{configuredId}` using a fresh App JWT.
2. POST `/app/installations/{configuredId}/access_tokens` using that JWT, body `{ repository_ids: [configuredRepositoryId], permissions: { metadata: "read" } }`.
3. GET `/repositories/{configuredRepositoryId}` using the returned restricted token.
4. GET `/user/{immutableOperatorId}` using that token.
5. GET `/repos/{canonicalOwner}/{canonicalRepo}/collaborators/{canonicalUser}/permission` using that token.

All paths are constructed locally. Response URLs and webhook names do not determine requests; canonical path segments are bounded/validated, and arbitrary URLs, separators and dot traversal are rejected. Redirects are never followed. Tests verify immutable-ID mismatch, canonical renames, reassigned login, transfer, custom role false positives, all four base permissions and unsupported/missing values, missing required fields, HTTP 301/302/307/401/403/404/429/500/503 at each phase, malformed JSON/UTF-8, chunking and exact/over-limit bodies, token scope/expiry, clocks, each fetch/body timeout, each fetch/body abort, late final-header abort and serialized-error redaction.

## RED / GREEN Evidence

All exact logs are in the sibling `task-4-evidence/` directory; no failed attempt was overwritten by a passing suite rerun on unchanged implementation.

| Log | Observed Result |
| --- | --- |
| `01-protocol-red.log` | RED: missing authority module (feature absent), 0 pass / 1 fail / 1 import error. |
| `02-protocol-green.log`, `04-protocol-green.log` | Not GREEN evidence: declared workspace link was not yet materialized; engine import unavailable. |
| `03-workspace-link-install.log` | Frozen install blocked by sandbox temporary-file EPERM. |
| `06-workspace-link-install.log` | Prescribed frozen install succeeded with approved escalation, no lock/source changes. |
| `07-protocol-green.log` | GREEN: 29 pass, 0 fail, 175 assertions. |
| `08-lifecycle-red.log` | RED: 102 pass / 14 fail, 637 assertions. Exposed deferred query snapshot, caller-abort classification and cleanup replacing primary body error. |
| `10-lifecycle-green.log` | Focused GREEN after fixes: 14 pass / 0 fail, 102 filtered, 97 assertions. |
| `13-token-expiry-red.log` | RED: 0 pass / 1 fail, 142 filtered, 2 assertions. Expiry was only detected at final permission stage rather than before user lookup. |
| `14-expanded-green.log` | GREEN after per-observation expiry guard: 143 pass / 0 fail, 865 assertions. |
| `05`, `11`, `15` focused lint logs | Implementation/test lint findings retained; corrected without changing configuration/rules. |
| `16-focused-lint.log` | 0 warnings / 0 errors. |
| `09-focused-typecheck.log` | Test fixture typing failures retained (branded digest, literal narrowing, readonly mutation test). |
| `12`, `17` focused typecheck logs | Exit 0 after using actual branded/literal contracts and reflective mutation in the snapshot boundary test. |

The final source adds first-observation timing and real engine-boundary checks to the 143-test expanded suite. Final full-gate adapter log is authoritative for the final 145 count.

## Final Sequential Gates

Executed once on final source via `task-4-evidence/run-final-gates.sh`, from the actual checkout, each command under `env -i PATH="$PATH" HOME="$HOME" TMPDIR="$TMPDIR"`. No affected-only/cache substitution or test retries. Runner stops on first failure.

Final gate outcome: **all available gates passed on final source, without rerunning the final block**. Five typechecks; 844 tests / 0 failures / 6561 assertions across 46 files. Existing property/law sources, counts and budgets were not changed; their complete available workspace suites were executed. No independent claim about a new law-case tally is made from assertion totals.

| Command | Result |
| --- | --- |
| `bun install --frozen-lockfile --ignore-scripts` | Exit 0, 212 installs / 264 packages, no changes. |
| `bun run check` | Exit 0, 0 lint warnings/errors and formatting clean. |
| `moon run domain:typecheck --force --no-actions` | Exit 0. |
| `moon run engine:typecheck --force --no-actions` | Exit 0. |
| `moon run probe:typecheck --force --no-actions` | Exit 0. |
| `moon run github-admission:typecheck --force --no-actions` | Exit 0. |
| `moon run github-adapter:typecheck --force --no-actions` | Exit 0. |
| `moon run domain:test --force --no-actions` | Exit 0; 211 pass, 0 fail, 965 assertions, 10 files. |
| `moon run engine:test --force --no-actions` | Exit 0; 300 pass, 0 fail, 2719 assertions, 16 files. |
| `moon run probe:test --force --no-actions` | Exit 0; 36 pass, 0 fail, 104 assertions, 7 files. |
| `moon run github-admission:test --force --no-actions` | Exit 0; 135 pass, 0 fail, 1828 assertions, 10 files. |
| `moon run github-adapter:test --force --no-actions` | Exit 0; 162 pass, 0 fail, 945 assertions, 3 files; includes 145 new authority tests. |
| `git diff --check` | Exit 0 in final block. Additional staged `git diff --cached --check` exit 0 before commit. |

`github-ingress:typecheck` and `github-ingress:test` are unavailable because that future workspace has not been created, explicitly recorded as SKIP. Summary/individual exact outputs: `final-gate-block.log`, `final-01-install.log` through `final-13-diff-check.log`.

The final block began at host UTC `2026-10-20T23:14:30Z` and completed at `2026-10-20T23:18:55Z` (2026-10-21 local BST). Commit output is saved in `final-commit.log`. Staging/commit required approved escalation solely because this worktree's Git index/object metadata is under the owning repository outside the writable checkout; no other checkout/branch was changed.

Integrity audit: `final-integrity-verified.log` records successful artifact equality, workspace-only lock delta, all 141 severities, physical Effect, versions, and exact final source SHA256s. Initial diagnostic audit errors are preserved in `final-integrity.log` (TypeScript 7 has no old parser API) and `final-integrity-attempt-2.log` (root is not an Effect consumer); corrected audit uses Bun's JSONC parser and the five actual consumers. These were audit-tool errors, not gate/test failures or source changes.

## Concerns And Handoff Boundaries

1. **Task 7 operator prerequisite:** this slice accepts PKCS#8 only. GitHub downloads PKCS#1. The operator must perform a separately approved local conversion into a protected PKCS#8 file before start; Task 7 must document this prerequisite and secret custody. This task did not read, convert or write any real key, add ASN.1 code or introduce a dependency. [GitHub private-key format](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/managing-private-keys-for-github-apps).
2. **Concrete Task 6 lifetime question raised to controller:** the native driver promise awaits reader cancellation and release, including a pending/rejecting cancellation; engine `Effect.tryPromise` interruption by itself is not proof that promise/finalizers settled. Does future composition track and drain in-flight native driver promises before claiming app disposal? No interface/runtime/waiver was added here, and direct driver tests do not qualify future app disposal. Deadline signals bound attempts/admission validity, not arbitrary uncooperative fetch or pending-cancel settlement; a permanently pending cancellation must not be falsely reported as completed shutdown. Task 6/7 retain bounded forced-exit/restart responsibilities.
3. **Synthetic compatibility only:** actual App installation permissions, real token responses and endpoint access remain unproven until the separately approved rehearsal. No listener, tunnel, worker/model, repository execution or GitHub write/rehearsal was initiated by this adapter task. The exact prescribed existing full-gate suites were run, not replaced with narrower synthetic claims.
4. **No zero-network attestation:** adapter tests inject fake fetch and synthetic keys/clock; documentation was read publicly. Frozen package tooling was explicitly permitted and its output says `Resolved, downloaded and extracted [2]`. Network was not traced, so this report does not claim the entire run had zero network or infer download provenance from that message. The complete external lock artifact graph is independently unchanged.
5. **Remote observation limitation:** the five reads are bounded sequential observations, not an atomic GitHub snapshot. Immutable IDs are checked where GitHub returns them; the final permission route necessarily uses freshly read canonical names. This does not prove remote state could not change between calls.
6. Controller owns ledger/review and dependent-task approval. No further task was started. No fresh reviewer was used, as explicitly required.

Additional primary documentation checked: [valid User-Agent](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api#user-agent), [JWT claims](https://docs.github.com/en/enterprise-cloud@latest/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-json-web-token-jwt-for-a-github-app), [permission endpoint and metadata read grant](https://docs.github.com/en/rest/collaborators/collaborators#get-repository-permissions-for-a-user), [restricted token response](https://docs.github.com/en/rest/apps/apps#create-an-installation-access-token-for-an-app).

## Fix Round 1/5: I1 Native Outcome And Cleanup Ownership

Date: 2026-10-21. Base source: `929c30191ce522808f18feff425c6e98294daf58`.
Read the Task 4 review and controller's explicit owned-resource ruling. Implemented personally without agents/reviewers; did not proceed to Task 5/6 or edit the controller ledger.

**Correction to the initial report:** I1 is a current Task 4 completion-contract defect, not merely a future app-disposal qualification question. The old driver could remain pending beyond either budget while cancellation/fetch ignored abort. The controller-approved resource contract below supersedes the old factory signature and the initial report's limitation framing.

### Fix

- The real native factory now returns a Result containing `{ driver, dispose }`, inferred from actual implementation. The engine's exported `LiveAuthorityDriver` itself is unchanged; no Effect channels, runtimes, services, waivers or dependency changes were added.
- `githubRequest` has a mandatory native-settlement ownership callback. Its attempt outcome races the two-second deadline/abort, independently of its retained native fetch/read/cancel/release promise. A known primary read/status failure is reported promptly without waiting for cleanup and is not replaced by a later cleanup error. A successful read still waits for its cleanup before success.
- The driver separately races its six-second total outcome. Orchestration and all request-native settlement promises remain in the acquired resource's owner set. A late fetch response is still acquired, cancelled exactly once and unlocked; no timed-out continuation can issue follow-up HTTP or yield successful evidence.
- At most four command owners may be outstanding, even after timeout. Additional calls return sanitized `signing/Unavailable` immediately without signing, clock or HTTP work. Actual native settlement frees capacity; finite failure alone does not.
- `dispose()` closes admission synchronously, aborts every owner through the shared lifetime signal, memoizes one disposal promise and awaits all real orchestration/HTTP settlement. Calls after closure return sanitized `signing/Aborted` without new work. If native fetch/cancellation remains stuck, disposal honestly remains pending. No timeout declares cleanup finished; the future main's ten-second nonzero forced-exit requirement is unchanged and not implemented/qualified here.
- Existing test callers acquire the explicit resource, pass its real `driver` to the engine boundary, and retain/await disposal. Pending-cancellation tests now distinguish prompt command failure from pending disposal rather than asserting that the command result must wait for cleanup.
- The shared factory contract in `docs/superpowers/plans/2026-10-20-local-github-ingress.md` and matching budget/ownership contract in `docs/superpowers/specs/2026-10-20-local-github-ingress-design.md` are updated in this same source fix. The ignored extracted `context.md` was refreshed consistently; `progress.md` was not modified.

### Focused RED / GREEN

Exact logs remain under `task-4-evidence/`:

| Log | Observed Result |
| --- | --- |
| `round1-01-deadlines-red.log` | 0 pass / 4 fail / 145 filtered / 4 assertions. Pending cancellation and abort-ignoring fetch still returned StillPending after the deadline, a known 403 failure waited for cancellation, and the original factory lacked the owned resource. Each synthetic pending operation was explicitly released by its test. |
| `round1-02-deadlines-green.log` | 3 pass / 1 fail / 145 filtered / 31 assertions. The behavioral deadline/primary-failure checks passed. The resource test hit a matcher issue: toMatchObject left ExpectAny values in callable fields. Replaced that assertion with nonmutating function-type checks; no production workaround/dependency change. |
| `round1-04-deadlines-green.log` | 7 pass / 0 fail / 145 filtered / 93 assertions, including active disposal, retained capacity, restored capacity and six-second total outcome. |
| `round1-05-typecheck.log` | Focused adapter typecheck exit 0. |
| `round1-06-adapter-suite.log` | 152 pass / 0 fail / 984 assertions on the adapted complete authority suite. |
| `round1-03-lint.log`, `round1-07-lint.log` | Test expression/callback lint findings retained, corrected without a rule/config change. |
| `round1-08-lint.log` | 0 warnings / 0 errors. |
| `round1-09-focused-green.log` | Final focused source: 7 pass / 0 fail / 145 filtered / 94 assertions. Added explicit zero clock-work assertion during saturation/closure. Total-outcome regression measured 6005.48 ms, before the still-pending final fetch was resolved. |

The regressions keep pending cancellation/fetch unresolved while observing finite outcomes, then explicitly release them and await actual settlement. They check held reader locks during pending cleanup, idempotent disposal, refusal after closure, no late lease/follow-up HTTP, four retained native slots after timeout, and positive capacity recovery after actual settlement. No real keys/API traffic, listeners, tunnels or app/worker/model activity were used.

### Round 1 Final Gates And Source

Final full available sequential block **passed once on final source**. Exact runner: `task-4-evidence/run-round1-final-gates.sh`; all logs go to the separate `task-4-evidence/round1/` directory, preserving initial Task 4 evidence. Commands retain the exact minimal explicit environment and prescribed pins; unavailable github-ingress gates are explicitly skipped. No baseline rerun, final-block retry or affected-only substitution. Host UTC start `2026-10-20T23:32:55Z`, finish `2026-10-20T23:37:30Z` (2026-10-21 local BST).

| Final Sequential Command | Actual Result |
| --- | --- |
| `bun install --frozen-lockfile --ignore-scripts` | Exit 0, lock unchanged. |
| `bun run check` | Exit 0; 0 lint warnings/errors, formatting passed. Moon notices are not represented as pristine output. |
| `moon run domain:typecheck --force --no-actions` | Exit 0. |
| `moon run engine:typecheck --force --no-actions` | Exit 0. |
| `moon run probe:typecheck --force --no-actions` | Exit 0. |
| `moon run github-admission:typecheck --force --no-actions` | Exit 0. |
| `moon run github-adapter:typecheck --force --no-actions` | Exit 0. |
| `moon run domain:test --force --no-actions` | 211 pass, 0 fail, 965 assertions, 10 files. |
| `moon run engine:test --force --no-actions` | 300 pass, 0 fail, 2719 assertions, 16 files. |
| `moon run probe:test --force --no-actions` | 36 pass, 0 fail, 104 assertions, 7 files. |
| `moon run github-admission:test --force --no-actions` | 135 pass, 0 fail, 1828 assertions, 10 files. |
| `moon run github-adapter:test --force --no-actions` | 169 pass, 0 fail, 1059 assertions, 3 files, including 152 authority tests. |
| `git diff --check` | Exit 0. Additional staged whitespace check passed before commit. |

Total: **851 tests / 0 failures / 6675 assertions across 46 files**, five typechecks. Property/law source and budgets remain unchanged; no law-case count is inferred from assertion totals. Final total-outcome regression measured 6005.32 ms before the final fetch was released; disposal subsequently awaited actual late reader cancellation.

`round1/final-integrity.log` successfully rechecks the unchanged external artifact graph, existing workspace-only link delta, all 141 rule severities, root override, physical Effect and tooling. It includes exact SHA256s of final source and both contract documents. Lock remains `d375b856e7760a67d0cf48ce683ee9d66ae14b75264c9cbe737ac1cf6bbe1de7`; both patch hashes remain unchanged.

Final fix commit: `c973182f59d04d296e2c148024113b8e36127734`, `fix: bound GitHub authority outcomes and own cleanup`. Verified tree: `23cc72b52590b21c967db73bc08747b2f4b5d3ab`. Exactly five tracked files changed: the two adapter modules, authority tests, and matching plan/spec contracts. Source SHA256s match the pre-gate integrity log; final tracked working tree is clean on `codex/local-github-ingress`. No dependency/config/rule/patch changes in this fix. Commit output and final identity/status are saved in `round1/final-commit.log` and `round1/final-source-identity.log`.

I1 is addressed in the verified fix source; controller-owned re-review/acceptance remains separate. No agents/reviewers, merge/push, branch/worktree changes or Task 5/6 implementation were performed.

Remaining boundaries: Moon update notice stays deferred (no notifier suppression or pin change); no zero-network attestation for the permitted frozen installer; PKCS#8 operator prerequisite and separately approved live rehearsal remain; actual future composition/forced-exit/restart proof is not inferred from native-resource tests.
