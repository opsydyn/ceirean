# SDD ledger — plan: docs/superpowers/plans/2026-10-20-local-github-ingress.md

## Identity And Authority

- Owner approved the written spec and selected subagent-driven plan execution.
- Checkout: /private/tmp/leviathan-compatibility; branch: codex/local-github-ingress.
- Baseline: 4fdf876987668ea61bab1be30e5d04c48f0515e0. Main remains unchanged.
- Reused the clean existing linked worktree; retained its earlier branch and other plans' scratch.
- No live credentials, GitHub requests, tunnel, deployment, merge or push authorised.
- Task 1: accepted (exact dependency compatibility and baseline gates; 50335af).
- Task 2: accepted (verified protocol extraction; e3ce253).
- Task 3: accepted (live schemas, inferred services, laws; f707065 after round1).
- Task 4: active (bounded native GitHub authority adapter).
- Task 5: pending (strict live SQLite/evidence/ownership).
- Task 6: pending (local CLI/listener).
- Task 7: pending (recovery/evidence/runbook/final review).

## Preflight Interface And File Scan

| Tasks | Producer / consumer or shared file | Finding |
| --- | --- | --- |
| 1 / 1 | Dependency metadata, strict tests, manifests, full gates | Internally consistent; optional app setup deferred to Task 6. |
| 2 / 2 | Extracted protocol versus legacy wrapper/tests | Digest test asserts transport preservation; no ledger logic belongs here. |
| 3 / 3 | Schema unions, factories and memory-driver laws | Live draft requires evidence plus local revision; legacy records remain unchanged. |
| 4 / 4 | Auth acquisition Result and cancellable driver | Acquisition is once; signing is SDK-owned; HTTP permissions remain synthetic proof. |
| 5 / 5 | Separate initialization/open, ledger versus owner sidecar | Explicit sidecar is operational state; no ledger transaction across network. |
| 6 / 6 | CLI modes, one runtime, listener/shutdown tests | State-only CLI modes must not acquire start credentials/runtime as a precursor. |
| 7 / 7 | Recovery, negative controls, measured report | Report records actual source/gates; live section remains unqualified. |
| 1 / 2 | Adapter manifest / protocol export | Exact accepted pins plus workspace links; no new runtime dependency. |
| 1 / 3 | Cohort / domain-engine implementation | Existing Effect and lint rules unchanged. |
| 1 / 4 | jose direct dependency / SDK auth | Task 4 may use only the Task 1 admitted artifact. |
| 1 / 5 | Bun FileSystem / local-state ownership | FileSystem does not supply flock; Task 5 uses explicit SQLite guard. |
| 1 / 6 | Platform pin / app manifest and Moon | App links admitted exact package; no new cohort decision in Task 6. |
| 1 / 7 | Compatibility assessment / final report | Preserve initial artifact and baseline identities rather than overwrite provenance. |
| 2 / 3 | VerifiedCommand / live service | Schema data is not a signature capability; only app verified callback calls admit. |
| 2 / 4 | Request/body handling / native response reads | Inbound and outbound reader lifetimes remain separately owned. |
| 2 / 5 | VerifiedCommand receipts / SQLite replay | No normalised command/body digest rewriting between these boundaries. |
| 2 / 6 | onVerified callback / app bridge | Shared handler does not allocate runtime; live projection is app-owned. |
| 2 / 7 | Legacy regression / whole-branch evidence | Existing tests and source-bound reports retain historical meaning. |
| 3 / 4 | AuthorityQuery and LiveAuthorityDriver / real factory | No request-local proof becomes shared fixture authority; native Promise driver is wrapped once. |
| 3 / 5 | LiveInboxDriver/draft / synchronous SQLite | Commit rereads uniqueness, revision and clocks atomically; no async driver contract. |
| 3 / 6 | Services / composition | One runtime provides real services; no inline provisioning in helper Effects. |
| 3 / 7 | Eight new laws / totals | 24000 new primary cases are separate from prior law counts and control runs. |
| 4 / 5 | Lease and provenance / durable record | Absolute monotonic tick is request-local; durable evidence records wall interval and immutable IDs. |
| 4 / 6 | AbortSignal and budgets / request ownership | Overall and sub-budgets may not detach committing work. |
| 4 / 7 | Synthetic API evidence / final/live report | No live permission claim from fake HTTP fixtures. |
| 5 / 6 | Ownership and state modes / listener/CLI | Start and configure acquire same owner guard; status is read-only without listener ownership. |
| 5 / 7 | Native transaction phases / SIGKILL checks | Actual child death, not close/reopen alone, is restart evidence. |
| 6 / 7 | Graceful and forced shutdown / recovery report | Nonzero forced exit cannot be labelled clean disposal. |

Ruling: Reuse the existing isolated checkout on a new branch from current main, rather than create an app-managed FoldKit worktree — this task belongs to Leviathan, not the chat's cwd — cost if wrong: checkout ownership needs rework, main remains untouched.
Ruling: Preserve inherited subagent model selection because the available spawn tool prohibits overrides without an explicit user model request — tool-specific constraint takes precedence over the skill's generic model-selection advice — cost if wrong: potentially higher review/implementation cost, no weakened review gate.
Ruling: Task 1 defers the runnable app workspace to Task 6 and admits its exact platform dependency in the adapter's real compatibility tests first — Task 1 explicitly permits this and avoids an empty app scaffold — cost if wrong: later manifest linkage may need correction.

## Execution

Task 1 base: 4fdf876987668ea61bab1be30e5d04c48f0515e0.
Task 1 implementer: 01a15b50-f6aa-7f72-a2d8-f7830e538f00 (Bernoulli), active; inherited model per tool constraint.
Task 1 brief: task-1-brief.md. Binding extracted context: context.md. Report: task-1-report.md.
Task 1 candidate: 50335af7f0c6077cfeee38045cb59fcb1be530a5; tree 328ce0c53445b545df27627918a6133dd1c21ed0. Author reports 649 tests / 4243 assertions, five typechecks, full check and artifact/identity gates. Review pending; not complete.
Task 1 review package: review-4fdf876..50335af.diff; source/lock changes isolated to the eight reported files. Main remains 4fdf876.
Task 1 reviewer: 01a15b5b-ffa8-7241-8e9b-a933c22c3ea7 (Darwin), active; task-1-review.md.
Task 1: complete (50335af7f0c6077cfeee38045cb59fcb1be530a5; spec compliant and quality Approved by Darwin; 649 tests / 4243 assertions, all available gates).
Task 1: minor (deferred): baseline-present Moon 2.6 update advertisements in gate logs; no lint warning/error and no failed test. Final review must triage; do not upgrade or filter diagnostics to hide it.
Task 1 controller closure: clean worktree and reviewed HEAD verified; strict base config, lint config and patches unchanged in the reviewed range. Historical author execution evidence is accepted as task evidence, not a fresh independent suite run. Later production/live gates remain open.
Task 2 base: 50335af7f0c6077cfeee38045cb59fcb1be530a5. Ready for a fresh implementer after Task 1 review.
Task 1 implementer/reviewer closed after accepted task review.
Task 2 implementer: 01a15b5e-04a1-70c1-81b9-775902947d2b (Locke), active; brief task-2-brief.md, report task-2-report.md.
Task 2 candidate: e3ce2537c291ca3936318feb787d3b4fe230be5d; tree 6aace25ffef3707252c66b9c9cf0002cc608b383; 662 tests / 4300 assertions, five typechecks and all available gates reported. Clean candidate verified; review pending, not complete.
Task 2 review package: review-50335af..e3ce253.diff. Report distinguishes resolved audit-script path errors from passing final code gates. Parent lock 74b793ca8c86d8dc38cad063675ce8be1f85cafc8241aae979f96a0b31e6f014; new workspace-link-only lock 13d9d8d647dc949b236108c7a5fc8a6d7798164583c5b4ed0d6c221af10e3e73.
Task 2 reviewer: 01a15b66-700e-7c82-adc1-67663d231d4a (Cicero), active; task-2-review.md.
Task 2: complete (e3ce2537c291ca3936318feb787d3b4fe230be5d; spec compliant and quality Approved by Cicero; 662 tests / 4300 assertions, five typechecks and all available gates).
Task 2: minor (deferred): same baseline-present Moon upgrade advertisement noise as Task 1, recorded explicitly here for final review; no source fix or rerun required by reviewer.
Task 2 controller closure: current reviewed HEAD and clean worktree verified, main unchanged. Historical execution-environment claims remain author evidence; future live/runtime/storage guarantees remain pending rather than inferred from this extraction.
Task 3 base: e3ce2537c291ca3936318feb787d3b4fe230be5d.
Task 2 implementer/reviewer closed after approval.
Task 3 implementer: 01a15b68-9112-7410-a1de-e8ee56c52e48 (McClintock), active; task-3-brief.md / task-3-report.md.
Task 3 candidate: 1b4618e8ce8f7f99abde2e05a6ed92ab6dfb40bc; tree c912abd9c0506847a1d1262ab6856de1bcd1cf52. Author reports 694 tests, eight laws / 24000 new primary cases, five typechecks and full gates. Report DONE_WITH_CONCERNS: required frozen installer printed two resolved/downloaded/extracted items; no network trace exists. Lock/config/patches unchanged; no credential-backed app operation claimed. Do not promote this to zero-network proof.
Task 3 review package: review-e3ce253..1b4618e.diff; review pending, not complete.
Task 3 reviewer: 01a15b7b-2e22-7540-88c7-c900d85b2a8e (Bohr), active; task-3-review.md.
Task 3: fix round 1/5, pending. Review Needs fixes: I1 malformed native Result containers escape sanitisation; I2 final commit misses monotonic rollback after reload; I3 live schemas admit impossible rejection/provenance pairs. Controller verified each against the exact reviewed source.
Task 3: minor (deferred): M1 memory duplicate resolution overwrites known receipt display metadata; M2 permutation law exercises reversed pre-admitted duplicates rather than paired fresh histories. Both stay visible for final whole-branch triage, not silently discarded or mandatory fix-loop scope.
Ruling: Extend the request-local LiveAdmissionDraft contract with evaluatedMonotonicMs for both local and live branches; compare final native commit time against that evaluation reading, and never persist this absolute tick in records — the spec requires rollback refusal but the plan omitted the reading needed to prove it — cost if wrong: cross-module/test and future native-adapter contract rework; no new runtime/dependency or retained monotonic authority. Update the written plan interface in the verified fix commit.
Task 3 cannot-verify closure (partial): current reviewed HEAD/clean status already checked. Unchanged domain checkLaw directly confirmed seeds 0/1/163, 1000 runs, size 50, maxShrinks 1000, maxDiscards 10000, matching 12000 domain + 12000 engine primary cases. Installer tracing and future native/live guarantees remain explicit unqualified boundaries.
Task 3 round1 candidate observed: f70706557b3988ec449c37a1d689a7b1fefc3f6c, clean worktree. Prepared scoped package review-1b4618e..f707065.diff; awaiting implementer's appended fix report/status before re-review.
Task 3 round1 report received: I1/I2/I3 RED/GREEN, 37 focused tests, 699 full tests, all available gates and 24000 new primary law cases preserved. M1/M2 remain deferred; installer tracing remains unqualified. Bohr resumed for scoped re-review; output task-3-rereview-1.md. Task still not accepted.
Calendar boundary: environment now 2026-10-21 Europe/London; original spec/plan identity remains 2026-10-20.
Task 3: fix round 1/5 complete (I1/I2/I3 ADDRESSED, no new Critical/Important breakage, Bohr task-3-rereview-1.md).
Task 3: complete (1b4618e..f707065; 699 workspace tests, five typechecks, 24000 new primary cases plus unchanged legacy laws, all available gates). Current reviewed HEAD f707065 and clean status checked; main remains 4fdf876. M1/M2 retained for final review; installer trace and future native/live guarantees not promoted.
Task 3 author/reviewer closed after acceptance. Docs-only checkpoint 450d5cf records reviewed Tasks1-3, execution selection and remaining gates; root check/format/whitespace and 24 local links pass, code/dependency diff from f707065 is empty. No redundant test rerun for that documentation-only checkpoint. Extracted context refreshed with the reviewed evaluation-tick field.
Task 4 brief: task-4-brief.md, report task-4-report.md; current parent starts at docs checkpoint 450d5cf. Native auth/body ownership and key-format/User-Agent notes explicitly provided in dispatch.
Task 4 base: 450d5cf3c8c6b03863328345a55c6cf9114b5102. Implementer 01a15b90-2036-78d3-9fd7-d9cbaee6f828 (Goodall), active. Clarified that no dependency changes means no new external artifact/cohort; explicit existing engine workspace linkage is allowed/required for own imports, with workspace-only lock delta.
Task 4 candidate observed: 929c30191ce522808f18feff425c6e98294daf58; clean worktree. Adapter suite 162 tests/945 assertions in saved final log; full report/status pending. Review package review-450d5cf..929c301.diff prepared. Lock d375b856e7760a67d0cf48ce683ee9d66ae14b75264c9cbe737ac1cf6bbe1de7; existing patch hashes unchanged in final audit. Not accepted until independent review.

Task 4 author report received: 844 tests / 6561 assertions, five typechecks and available gates; exact source/tree and raw logs retained. Native promise cleanup versus Effect interruption remains an explicit Task6/7 ownership question, not app-disposal proof. No new ruling on interface changes has been made.
Task 4 reviewer: 01a15b9f-b596-7b61-99f3-d66258de9438 (Carver), active; task-4-review.md. Review package and constraints provided, including the unresolved lifetime boundary without a predetermined verdict.

Task 4: fix round 1/5. Carver found I1: pending reader.cancel or abort-ignoring fetch leaves the native driver unresolved beyond attempt/total deadlines (focused check still pending at2302ms). Controller confirmed github-http release awaits cancellation and githubRequest has signals but no finite outcome race. This is a current contract gap, not merely future app qualification. Minor Moon notice remains deferred.
Ruling: Make the native authority acquisition return an explicit owned resource containing the existing driver plus idempotent asynchronous disposal; separate finite command outcomes from tracked native cleanup, and cap outstanding owned operations at four even when cleanup is uncooperative — arbitrary native Promises cannot be forcibly settled, while the spec requires both finite responses and truthful bounded failed shutdown — cost if wrong: private factory/fixture and later composition rework. No new dependency, runtime, cache or permission grant; disposal must abort and actually await all owned native work, not claim success on a timeout. Task6 retains the ten-second nonzero forced-process-exit responsibility. Update the shared plan/spec contract in the fix commit and add focused pending-fetch/pending-cancel deadline and disposal tests.

Task4 round1 candidate: c973182f59d04d296e2c148024113b8e36127734, clean status verified; tree23cc72b52590b21c967db73bc08747b2f4b5d3ab. 851 tests /6675 assertions, five typechecks and available full gates;7new regressions distinguish finite outcomes from native drain. Source/plan/spec amended; no dependency delta. Scoped review package review-929c301..c973182.diff; Carver resumed, output task-4-rereview-1.md. Task not yet accepted.

Task 4: fix round1/5 complete; Carver task-4-rereview-1.md marks I1 ADDRESSED under explicit owned-resource contract and no new Critical/Important breakage.
Task 4: complete (929c301..c973182;851 tests, five typechecks, full available gates). Native finite outcomes and truthful disposal drain accepted; future app lifecycle remains unqualified. Author/reviewer closed. Minor Moon notice remains deferred.
Task5 base:c973182f59d04d296e2c148024113b8e36127734. Prepared brief task-5-brief.md; binding context reflects native resource amendment.

Task5 implementer:01a15baf-c95d-7ae1-92d8-ba57c9ebebc3(Feynman), active; task-5-report.md. OnlyTask5 write scope; no futureappwork. Realchild-lock qualification required before acceptance.

Task5 author NEEDS_CONTEXT before production edits: custom stateRoot policy. Partial baseline unnecessarily repeated by author: check,five typechecks,domain211/engine300; this is not taskverification and not fullgateproof. Remaining baseline not needed; final changed-source fullblock mandatory.
Ruling: Permit an explicitly operator-selected absolute custom production stateRoot outside the default Application Support base, subject to verified owner-only root, safe nonsymlink components, database containment and explicit repo/build/temp/known-sync exclusions; document that the operator declares a local nonsynced filesystem and arbitrary sync/network software cannot be inferred from pathname — the spec expressly allows overrides on other hosts, so restricting all hosts to macOS Application Support would contradict it — cost if wrong: path-policy and operator-configuration rework; no silent locality attestation or weakened test/prod separation.

Task5 candidate:17ed64a823485c3c6093d7119889a6c8d6ee818c; tree53f2f44ec812716c96dfcddc9d7cba46b5a2a5d9, cleanstatusverified. 876tests, fivechecks, fullgates authorreport;25newpath/storagecases. Earlierpassingqualification preserved separately aftersourcechanged; finalsourcegates rerun legitimately. Initialbatch lacks cleanperbehaviorREDhistory (disclosed); semanticregressions provideREDGREEN. Report's '851base' sentence confuses prior testcount withSHA; actualc973base correct. Reviewpackagereview-c973182..17ed64a.diff prepared. Notacceptedpendingreview.

Task5 reviewer:01a15bdc-4977-7e20-a4ac-42073113a73b(Planck), active;task-5-review.md. Freshcombinedspec/qualityreview, nofullreruns. Feynmanretainedforfixloop.

Task5 review Needsfixes (Planck): I1 test nativeInterleaving only proves Busy then sequentialsame-driver outcomes, not anotherconnectionactuallycommitting winner/policy; I2 recordFresh/finalizeFresh duplicate securitysensitivevalidation. Controller verified duplicatedbranches and competingconnectionBEGIN/ROLLBACKonly; fixround1/5. No newruling needed, preserve bothbarriers and realownerguard. InitialTDDhistorylimitation remains disclosed and cannotberetroactivelyproved.

Task5 round1candidate:bb2c3cd01fe355f76fbd327c79c64dc240f90937, treebea410fa0fdf070bee7d664a3a37deb506deee2b, cleanverified. I1/I2authorfixes with3restoredREDmutationchecks,878tests/fivechecks/fullavailablegates. Reviewpackagereview-17ed64a..bb2c3cd.diff; Planckresumedscopedrereview task-5-rereview-1.md. Notacceptedpendingverdict.

Task5: fixround1/5complete; Plancktask-5-rereview-1.md I1/I2ADDRESSED, nonewfixbreakage. Task 5: complete (17ed64a..bb2c3cd;878tests/fivechecks/fullavailablegates). Author/reviewerclosed. NativeSQLite/localmacOS/processdeathproofonly; no deployment/liveclaim. HistoricalinitialTDDlimitationretainedforfinalreport.
Task6base:bb2c3cd01fe355f76fbd327c79c64dc240f90937; briefready task-6-brief.md. NativeauthorityresourceandstoragepathPolicyrefinements mustbeconsumedexplicitly.

Task6 implementer:01a15be9-be18-7713-90a9-fcde66e1c8bb(Volta),active. Explicitbrief/context/acceptednativecontracts; no prechangebaseline rerun. Sixworkspacegates required onceappcreated, actualephemeralloopbackandforcedshutdownchildqualification. No realcredentialAPI/tunnel orTask7work.

Task6 author NEEDS_CONTEXT: proposed extra LEVIATHAN_HOST_CONTEXT environment JSON for trusted filesystem inputs before edits.
Ruling: Do not add a second required environment-JSON configuration channel. Derive host UID/cwd and conventional exclusions at the native application boundary, read HOME/TMPDIR through Effect Config as needed, and keep injectable typed host context for tests. Treat the operator-authored explicit stateRoot and invocation under the runbook's local-nonsynced requirement as the filesystem declaration, not mechanical proof; preserve the specified four-key CLI config. Repository ancestor markers and known temp/sync roots remain native checks, with conventional current-project build exclusions; document limits for arbitrary external build/sync/network setups — a hidden required JSON environment duplicates the explicit config and creates unnecessary operational ambiguity — cost if wrong: host-context acquisition/path-policy and runbook rework, not expanded GitHub authority or new dependencies. Production may not accept TestOwnedTemporary or undeclared ambient secrets.

Task6 candidate:e8fb83c437ebcf1709be4f0e119597319728c653, tree4a745f96d5d0569cfb17d395f8cc8b61ef3b3afc, cleanverified. Author903tests/6typechecks/fullgates; lock8cb4d58bd88280daee28101e542cd9b7120ec7ee63dd5094daf59c2a45fddf59, workspace-onlydelta. Reportand28rawlogsarchive forcecommittedunderSDDignoredtree byauthor (unlikeearliertasks); canonicaldurablearchive/cleanup requiresTask7correction, nohistoryrewriting. Reviewerexplicitlyinformedtoscopeassess ratherthansilentlyacceptscratchtracking. Reviewpackagereview-bb2c3cd..e8fb83c.diff ready. Tasknotaccepted.

Task6 reviewer:01a15c0e-b1db-78d1-9d13-0b8810f43a80(Meitner),active;task-6-review.md. Volta retainedforfixloop.

Task 6: complete (e8fb83c;903tests/sixchecks/fullgates; MeitnerspecPASS/applicationqualityApproved). Author/reviewerclosed. MinorTask6M1: late malformed-key acquisition unwind and bind-failure regressioncoverage gap; code cleanupnotobservedbroken. MinorTask6M2: scratchtracking requirescanonicalrelocation. PriorM1/M2/Moonremainforfinaltriage.
Ruling: Relocate Task6's force-tracked SDD report/evidence to the Task7 canonical durable docs/evidence archive, verify lossless hashes, and remove only tracked scratch copies from the index while retaining local recovery files until final review — the skill's scratch lifecycle must not become a second permanent evidence convention — cost if wrong: evidence path/index correction, with original bytes preserved and no history rewrite.
Task7base:e8fb83c437ebcf1709be4f0e119597319728c653. Brief+task-7-evidence-handoff.md ready. Finaltaskreview and separatefreshwholebranchreview remainmandatory; noauthorreviewerdispatch.

Task7 implementer:01a15c12-33e7-76d1-8391-642eb2853dc5(Dalton),active;task-7-report.md. Canonicalarchive+losslessscratchrelocation authorized, nohistoryrewrite. FivecontrolstwiceREDandrestoredGREEN required. Finalcontrollerwholebranchreview notdelegatedtoauthor.

Controllercheckedmainread-onlyduringTask7: /Users/alancurrie/Projects/Leviathan clean at4fdf876, untouchedbyimplementation. No integrationapproval inferred.

## Handoff Notes For Later Tasks

- Task 2 must add exact already-qualified @flue/github/@flue/runtime and domain workspace declarations to its own manifest before importing them; this is explicit linkage to admitted artifacts, not permission for a new cohort.
- Task 7 must retain durable source-bound raw gate/control/review evidence referenced by the final report before the skill's final scratch cleanup. Historical source identities must remain distinct from later evidence/docs commits. No live claims from synthetic checks.
- Task 4/7 key-format prerequisite: GitHub's official managing-private-keys documentation says downloaded App keys are PKCS#1 RSAPrivateKey. The approved SDK path explicitly uses jose importPKCS8. Source: https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/managing-private-keys-for-github-apps (read-only verified during Task 3; no key accessed).
- Task 4 source check: GitHub REST requires a valid User-Agent; the plan's two named headers are not an exhaustive ban on this required header. Include an explicit fixed application User-Agent and test it. Source: https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api#user-agent . JWT primary contract: RS256, App ID/client ID issuer, expiry no more than ten minutes into the future, recommended iat sixty seconds back; https://docs.github.com/en/enterprise-cloud@latest/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-json-web-token-jwt-for-a-github-app . These were read-only documentation checks, not live API qualification.
- Task 4/6 cross-task review focus: abort propagation through a Promise driver is not alone proof that native body-reader cancellation/finalisation settled. Qualify real ownership through app disposal and the bounded failed-shutdown path; no detached late commit or false clean close. If the prescribed driver contract cannot expose the necessary ownership, raise a concrete controller question before inventing a second runtime or weakening the cleanup promise.
- Task 5 primary source checked while Task4 runs: https://www.sqlite.org/lang_transaction.html section 2.2 says BEGIN EXCLUSIVE starts a write transaction immediately; in rollback journaling it prevents other connection reads, while WAL EXCLUSIVE equals IMMEDIATE. The selected owner sidecar must use rollback journaling and stay separate from the WAL admission ledger. This supports the proposed mechanism but is not Bun/native/process-death qualification; those tests remain required.
Ruling: Retain the approved PKCS#8-only SDK import contract, make unsupported PKCS#1 fail as InvalidKey, and require a documented operator-owned local conversion prerequisite before the separately approved live rehearsal — this avoids inventing DER conversion or a new dependency under a security-sensitive adapter — cost if wrong: one extra setup step or a blocked live rehearsal; never silently accept an unsupported key. Task 4 must test the format boundary with synthetic data; Task 7 must document it without reading/converting real keys.
