### Spec Compliance

- PASS: Task 6 application requirements are satisfied in the supplied diff. Reviewed personally, without agents, for base bb2c3cd01fe355f76fbd327c79c64dc240f90937 to head e8fb83c437ebcf1709be4f0e119597319728c653 in /private/tmp/leviathan-compatibility.
- PASS: The mapped app source/tests, private manifest, strict tsconfig, explicit uncached Moon project and workspace-only lock additions are present. No new dependency versions, lint changes, engine/adapter changes or lowered budgets appear (apps/github-ingress/package.json:13; apps/github-ingress/tsconfig.json:3; apps/github-ingress/moon.yml:4; bun.lock:15).
- PASS: One ManagedRuntime boundary assembles the scoped inbox, owned authority resource and engine services before the CLI binds; failed acquisition disposes the runtime. Non-start invocation selects state/config administration rather than start acquisition (apps/github-ingress/src/composition.ts:1; apps/github-ingress/src/cli.ts:6). The actual authority resource is used as { driver, dispose }, not treated as a bare driver.
- PASS: Four concurrent owners, 60 starts per rolling 60000ms with exact-expiry removal, eight-second request outcomes, retained cleanup ownership and loopback-only POST /webhook are implemented (apps/github-ingress/src/listener.ts:38). Existing six-second authority/two-second attempt behavior is exercised through the composition, not recreated with another runner (apps/github-ingress/tests/restart.test.ts:1).
- PASS: Disposal stops accepts, aborts and awaits owned request work/transport, then disposes the runtime. Authority acquisition follows scoped storage acquisition, so native authority disposal precedes the storage child-scope close; stuck native settlement remains pending. Main owns the ten-second forced exit and emits only FailedShutdown before exit 1 (apps/github-ingress/src/main.ts:8; packages/github-adapter/src/live-sqlite-inbox.ts:514; packages/github-adapter/src/github-authority.ts:308).
- PASS: Schema-decoded four-key config/argv, credential-free init/status/configure, revision-checked stopped-owner configure, explicit owner-only credential references, sanitized public projection and side-effect-free public imports are implemented and covered by synthetic tests (apps/github-ingress/src/config.ts:31; apps/github-ingress/src/responses.ts:1; apps/github-ingress/tests/cli.test.ts:1; apps/github-ingress/tests/restart.test.ts:471).
- PASS: Host handling follows the controller ruling: Effect Config HOME/TMPDIR, native UID/cwd, conventional build/known-root checks, production pathPolicy translation, and an injected-only temporary bypass. The README explicitly makes invocation the local/non-synced declaration without claiming arbitrary sync/network discovery (apps/github-ingress/README.md:28; apps/github-ingress/src/config.ts:85; packages/github-adapter/src/local-state.ts:69).
- LIMIT: 903 tests, six typechecks, 141 error-severity rules and physical dependency integrity remain author qualification evidence, not independently rerun results. The archived app log was inspected and records 25 passing tests, zero failures and 354 assertions. No independent live GitHub/App/tunnel acceptance was performed or inferred (.superpowers/sdd/2026-10-20-local-github-ingress/task-6-report.md:72).
- LIMIT: Force-tracked SDD report/evidence is an extra commit-scope decision, not acceptance of scratch tracking or a substitute for Task 7's unimplemented canonical durable evidence archive. Controller disposition remains required; see Minor 2.

### Strengths

- Real ownership is preserved across finite outcomes: listener timeout does not pretend cleanup finished, the original request body reaches the adapter, and authority disposal awaits abort-ignoring native work (apps/github-ingress/src/listener.ts:38; packages/github-adapter/src/request-body.ts:103; packages/github-adapter/src/github-authority.ts:308).
- Tests cover real signed synthetic ingress and ephemeral HTTP, replay/conflict with unavailable fake API, body/evidence/commit-boundary cancellation, clean and forced child-process shutdown, and separate ledger recovery. Controlled timers/deferred phases avoid arbitrary sleeps; no real credentials or live service are necessary (apps/github-ingress/tests/listener.test.ts:1; apps/github-ingress/tests/restart.test.ts:1).
- Public replies do not expose records, policy, evidence or native exception text; durably recorded local refusals are distinguished from admitted previews (apps/github-ingress/src/responses.ts:17).

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

- None found in the Task 6 application implementation.

#### Minor (Nice to Have)

1. apps/github-ingress/tests/restart.test.ts:95 and apps/github-ingress/src/cli.ts:19: The credential-failure test rejects a 0644 key before storage acquisition. It does not pin the later unwind paths: a 0600 malformed key after inbox acquisition, or a bind failure after successful composition. The code has scoped/runtime cleanup for both, so this is a regression-coverage gap, not an observed leak. Add focused cases asserting rejection, immediate subsequent ownership acquisition, unchanged ledger and no residual listener.
2. .superpowers/sdd/2026-10-20-local-github-ingress/task-6-evidence/21-evidence-packaging.md:17 and task-6-report.md:131: The commit adds report/evidence under the otherwise ignored SDD scratch tree, including a binary log archive. Lossless packaging addresses console fidelity/whitespace, not whether tracking scratch is in scope. This differs from earlier tasks and creates a second evidence-retention convention before Task 7 establishes the canonical durable archive. Preserve the evidence, but have the controller explicitly decide retention/relocation before integration; this review neither authorizes force-tracking nor implements Task 7. The initial TDD material is summary/excerpt evidence, while the supplied 28/28 archive comparison concerns raw gate logs; do not conflate them.
- DEFERRED: The inspected app gate contains Moon's existing update-available notice (.superpowers/sdd/2026-10-20-local-github-ingress/task-6-report.md:113). It is not pristine output, but remains in the already-deferred final triage alongside Task 3 M1/M2. No tooling update or unrelated remediation is requested here.

### Checks Performed

- Read task-6-brief.md, context.md and task-6-report.md. Read the supplied 2680-line review package in bounded ranges; repeated only output omitted by tool truncation. No changed source file was separately reread.
- Named cross-contract risk: interrupted body capture might release a request owner before actual reader cleanup. Checked packages/github-adapter/src/request-body.ts:17-126; acquireUseRelease awaits cancellation and releases the reader lock.
- Named cross-contract risk: treating authority outcomes as native settlement could close storage too soon. Checked packages/github-adapter/src/github-authority.ts:73-107 and :246-325; finite outcomes are separate from retained native settlements and dispose waits for those settlements.
- Named cross-contract risk: failed start acquisition or application shutdown might leak/close storage out of order. Checked packages/github-adapter/src/live-sqlite-inbox.ts:514-564; open forks a parent-owned child scope and closes it on acquisition failure; admin operations are scoped.
- Named cross-contract risk: app-supplied host policy might omit required exclusions or expose test storage through CLI JSON. Checked packages/github-adapter/src/local-state.ts:1-180 against the diff's production/test translation; storage validates containment, known exclusions, repository ancestors, ownership, modes and symlinks independently.
- Evidence visibility check: extracted only archived 14-github-ingress-test.log to stdout; confirmed its reported app results and Moon notice. The supplied prior 28/28 byte comparison was not independently repeated.
- No git commands, full gates, tests, installs, broad crawl, subagents, real key/API use, live listener/tunnel start, merge or push. No focused test was necessary to answer a remaining concrete behavioral doubt. Only task-6-review.md was written.

### Assessment

**Task quality:** Approved for the application implementation, with the minor coverage and artifact-scope items above.

**Reasoning:** The composition and cancellation paths respect the actual resource contracts and maintain truthful cleanup ownership through forced shutdown. This is a Task 6 source review approval, not acceptance of force-tracked scratch, completion of Task 7, independent rerun qualification, live acceptance, or merge approval.
