# Task 1 Report: Local GitHub Ingress Cohort

## Status And Ownership

**DONE.** Task 1 only. Full baseline, compatibility RED/GREEN, strict declaration
checking, artifact qualification and all available full gates passed. The
verified task-only commit is recorded below.

- Checkout: `/private/tmp/leviathan-compatibility` (verified Git top-level).
- Branch: `codex/local-github-ingress`; no switch or new worktree.
- Baseline HEAD and main ref: `4fdf876987668ea61bab1be30e5d04c48f0515e0`.
- Git common directory: `/Users/alancurrie/Projects/Leviathan/.git`.
- Initial tracked/untracked status: clean. Existing ignored plan/sibling scratch preserved.
- FoldKit checkout was not edited. No agents/reviewers dispatched, progress ledger
  edits, merge, push, live credential access, ingress listener or GitHub API calls.
- Application workspace explicitly deferred to Task 6; no production API exports,
  placeholder module, application scaffold or controller runtime added.
- Independent review remains the controller's responsibility.

## Files

Commit only these eight task files:

1. `.moon/workspace.yml`: register `github-adapter`.
2. `package.json`: exact root node-shared override; existing pins unchanged.
3. `bun.lock`: new adapter workspace and exact admitted dependency resolution.
4. `packages/github-adapter/package.json`: private workspace, direct jose/Effect,
   platform-bun development dependency, strict typecheck script.
5. `packages/github-adapter/tsconfig.json`: existing strict base, `skipLibCheck: false`.
6. `packages/github-adapter/moon.yml`: exact explicit uncached/no-retry/envFile-false tasks.
7. `packages/github-adapter/tests/compatibility.test.ts`: four real compatibility tests.
8. `docs/assessments/local-github-ingress.md`: initial compatibility qualification.

Local, ignored task evidence is retained in this plan workspace, including
`task-1-gates.sh`, `task-1-qualify.mjs`, this report and `task-1-evidence/`.
Nothing under `.superpowers/` is part of the commit. The controller's ledger
and all sibling scratch are untouched.

## Baseline Evidence

Full exact gate block, omitting only the not-yet-created github-adapter and
github-ingress workspaces, ran sequentially before task tests/manifests were added.
`task-1-evidence/baseline/` contains each exact command (`*.command`) and full
stdout/stderr (`*.log`). `baseline-identities.log` records source/tool/hash state.

All baseline gates exited 0:

- `bun install --frozen-lockfile --ignore-scripts`.
- `bun run check` (0 lint errors/warnings and clean format).
- `moon run PROJECT:typecheck --force --no-actions`, ordered domain, engine,
  probe, github-admission.
- `moon run PROJECT:test --force --no-actions`, same order.
- `git diff --check`.

Actual baseline counts: domain 201/201 (768 assertions), engine 273/273
(1526 assertions), probe 36/36 (104 assertions), github-admission 135/135
(1828 assertions): **645 pass, 0 fail, 4226 assertions across 39 files**.
No law counts, seeds, budgets, test selection, or lint settings were reduced.

The first sandboxed baseline install could not write to tempdir (`EPERM`);
the scoped escalation authorized the frozen script-free baseline install and
remaining sequential gates. This was an infrastructure failure before suites
ran, not a retried failing suite. Public npm fetches also required escalation
after sandbox DNS resolution failed. No new policy waiver was requested.

## TDD Evidence

1. Added direct-import tests before manifests or dependency installation.
2. Ran `bun --no-env-file --no-install test
   packages/github-adapter/tests/compatibility.test.ts --timeout 30000`.
   `task-1-evidence/focused-red.log`: exit 1, 0 pass, 1 fail, 1 import error:
   cannot find `@effect/platform-bun`. This is the required **compatibility RED**,
   not a claimed behavioral RED. Jose already existed transitively in the baseline.
3. Verified exact public artifacts before the single non-frozen candidate install;
   added manifests/root override/Moon tasks; ran `bun install --ignore-scripts`
   once. `candidate-install.log`: exit 0, 3 installed packages; no lifecycle scripts.
4. `focused-green.log`: exit 0, 4 pass. `focused-typecheck.log`: strict new
   workspace typecheck passed, including imported declarations.
5. The preliminary `focused-check.log` caught 17 lint style errors in new test
   callbacks, branching and nested calls. Tests were reshaped to existing named
   generators/flat pipelines and explicit failure effects. No rule was changed.
   `refined-check.log` then had zero lint errors but root-manifest formatting
   needed correction. Oxfmt formatted only task-owned files.
6. Self-review strengthened chmod to prove file transitions 0600 -> 0400 -> 0600
   and directory transitions 0500 -> 0700, not only reapply an unchanged mode.
   `final-focused-green.log`: exit 0, **4 pass, 0 fail, 17 assertions**.

The four tests exercise fresh synthetic RSA PKCS8 key export/import, RS256 JWT
sign/verify with literal claims and explicit synthetic verification time, a wrong
verification key, malformed header and malformed encoded key refusal, real Bun
filesystem exclusive creation/typed AlreadyExists/content preservation/chmod,
and scoped cleanup on success and typed failure. No mock filesystem, hand-rolled
crypto, credential fixture from ambient files, HTTP call or listener is involved.

## Source, Lock And Artifact Identities

Tools observed: Bun 1.4.2 (`744846f84`), Node 24.15.0 (tooling only), Moon 2.5.4.
Existing Effect 4.0.5, Flue 2.3.0, TypeScript 7.0.2, bun-types 1.4.2,
oxlint 1.88.0, oxfmt 0.73.0, Effect lint 2.0.1 and XState pins are unchanged.

- Baseline lock SHA256:
  `a03b2f20874301814ba165f945b3fa55df5f20023f29ba5b873f3d16537cadc3`.
- Qualified lock SHA256:
  `74b793ca8c86d8dc38cad063675ce8be1f85cafc8241aae979f96a0b31e6f014`.
- Unchanged Flue declaration patch SHA256:
  `07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a`.
- Unchanged Gaxios declaration patch SHA256:
  `7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e`.
- Unchanged lint config SHA256:
  `a4ee5835f4246a48d82ecc569aa533db3a22dd27b24d66c3acdec396bc25ca9d`.

Exact artifact SHA512 values (metadata = downloaded tarball = lock):

| Artifact | Integrity | Installed Files Compared |
| --- | --- | --- |
| jose 6.2.12 | `sha512-9NiFmJEex0sy2Dk58j2UGBSHgUs2ypF9eZSu4L6vjOX3Dp96Sw1F3uL+H+D1sx02jZZdzUT0HgvCy59CuvXcWw==` | 80 |
| @effect/platform-bun 4.0.5 | `sha512-tB/GapZ/bVoCbwRgnojGP4TwopvkMoFoSCipXT1sf0guvG/2oRVhWzJW/1vkrYFEdLM7XyRnVVLrSJyqdok7DA==` | 217 |
| @effect/platform-node-shared 4.0.5 | `sha512-a8rCdEkfZBGe9C6bsIjxVZuRp73svIyK5IHwHdDAVsvZXjrbkxusfI+rZ8WlX31RP1mKizwI/E72GQTNfdMWHw==` | 182 |
| @types/ws 8.18.2 | `sha512-67MQl+fpWKVTT1NYdnmo3U4sc/xPo/zQBncVnI74qmQa0z/b+1g6iYqNmGCPbxO+zz2aklb08a0oHfegiVd0/w==` | 5 |

Raw metadata, tarballs, extracted artifacts and validation output are in
`task-1-evidence/`. `final-qualification.log` verifies each shipped export/peer/
dependency declaration against metadata and byte-compares **484 installed files**
with their verified archives. Initial metadata comparison used JSON string order;
the apparent exports mismatch was only object-key ordering and was resolved by
structural comparison before install. No artifact mismatch was found.

The qualification script parses Bun JSONC lock structure and confirms all **262**
baseline package entries and existing workspace entries are unchanged. New lock
entries are exactly platform-bun, platform-node-shared, the adapter workspace link
and @types/ws. Jose is a new direct dependency, not a new lock artifact.
Node-shared declares `ws: ^8.22.0`, `@types/ws: ^8.18.2`; existing ws 8.22.0 is
unchanged, while new @types/ws 8.18.2 reuses existing @types/node 26.6.5.
Platform peer Effect `^4.0.5` resolves to the pinned 4.0.5. Root override pins
node-shared 4.0.5 despite platform-bun's `^4.0.5` range. Jose has no dependencies
or peers. No direct Hono/Octokit/Node-controller dependency was added.

Physical traversal found one Effect installation at
`node_modules/.bun/effect@4.0.5/node_modules/effect`. All five workspace resolution
checks plus both platform packages resolve to it. The existing lint configuration
is byte-identical to baseline and all 141 imported Effect rules resolve to error
severity. No new boundary/ignore/disable/patch/helper provisioning waiver exists.

## Full Gates And Final Commit

Executed `sh .superpowers/sdd/2026-10-20-local-github-ingress/task-1-gates.sh full`
after the final test/assessment edits. `task-1-evidence/full/` retains each exact
command and its complete output. In order, every command exited 0:

```sh
bun install --frozen-lockfile --ignore-scripts
bun run check
moon run domain:typecheck --force --no-actions
moon run engine:typecheck --force --no-actions
moon run probe:typecheck --force --no-actions
moon run github-admission:typecheck --force --no-actions
moon run github-adapter:typecheck --force --no-actions
moon run domain:test --force --no-actions
moon run engine:test --force --no-actions
moon run probe:test --force --no-actions
moon run github-admission:test --force --no-actions
moon run github-adapter:test --force --no-actions
git diff --check
```

Only github-ingress tasks are omitted, because its workspace is explicitly
deferred to Task 6. No affected-only/cached substitution or failing suite retry.
Full check: **0 lint warnings, 0 lint errors**, clean formatting. All five
typechecks passed; adapter declarations checked with skipLibCheck false.

| Suite | Pass | Fail | Assertions | Files | Runtime |
| --- | --- | --- | --- | --- | --- |
| domain | 201 | 0 | 768 | 8 | 43.71 s |
| engine | 273 | 0 | 1526 | 14 | 143.36 s |
| probe | 36 | 0 | 104 | 7 | 1.445 s |
| github-admission | 135 | 0 | 1828 | 10 | 2.48 s |
| github-adapter | 4 | 0 | 17 | 1 | 0.195 s |
| Total | **649** | **0** | **4243** | **40** | |

After all gates, `task-1-qualify.mjs` ran again with exit 0 and retained exact
post-gate qualification in `post-gates-qualification.log`. All identities,
existing lock entries, physical Effect resolution and 141 rule severities
remained unchanged from the successful pre-gate qualification.

Commit: `50335af7f0c6077cfeee38045cb59fcb1be530a5`
(`test: qualify local ingress authentication cohort`).
Committed tree: `328ce0c53445b545df27627918a6133dd1c21ed0`.
Staged diff was checked before commit; exactly the eight task files above were
committed (236 insertions). `verified-task.patch` preserves the exact staged
patch. Post-commit status is clean on `codex/local-github-ingress`; main remains
at `4fdf876987668ea61bab1be30e5d04c48f0515e0`. No merge or push performed.

All install/test/typecheck/check commands run with
`env -i PATH="$PATH" HOME="$HOME" TMPDIR="$TMPDIR"`; no ambient credentials are
passed to them. Public npm metadata/tarball/install tooling is the only newly
requested network activity. The task-local Node built-ins in the evidence script
inspect artifacts; they do not introduce a production Node fallback.

## Self-Review And Concerns

- Reviewed every task-owned file and lock delta against Task 1 and context.
  No dependent-task implementation, generic placeholder export, runtime, service
  factory, manual Effect/Layer channels, new vendor patch or declaration waiver.
- Tests fail on wrong signing keys, malformed imports, nonexclusive creation,
  no-op chmod, changed content and leaked scoped directories. Both test execution
  boundaries use the actual published BunFileSystem layer; platform errors in
  the intentional-failure test remain test failures, not accepted cleanup proof.
- Synthetic signing uses a freshly generated key held only in memory. All
  filesystem writes are test-owned temporary paths, cleaned by real scopes.
- No new blockers, waivers or cohort changes. Independent controller review is
  pending, as required; this is author self-review only.
- Limits: macOS/Bun cohort qualification only, not production path/symlink safety,
  app lifecycle, request cancellation, database custody, live authorization or
  rehearsal acceptance. The Task 6 app must declare platform-bun itself.
