# Task 5 Implementer Report

Status: DONE_WITH_CONCERNS (initial-batch TDD-history limitation documented below).
Task 5 only, implemented personally. No agents or reviewers dispatched.

## Identity

- Actual checkout: `/private/tmp/leviathan-compatibility`
- Branch: `codex/local-github-ingress`
- Actual base/parent: `c973182f59d04d296e2c148024113b8e36127734`
- Base tree: `23cc72b52590b21c967db73bc08747b2f4b5d3ab`
- Commit: `17ed64a823485c3c6093d7119889a6c8d6ee818c`
- Subject: `feat: persist immutable live admission evidence`
- Final tree: `53f2f44ec812716c96dfcddc9d7cba46b5a2a5d9`
- Exact final-source file hashes: `task-5-evidence/final-source-sha256.txt`.

Correction: `851` referred to the previously verified test count, not a base
SHA. There was no reported base mismatch; the actual parent is recorded above.

## Implemented

- Explicit `./storage` package export with scoped initialize/open and read-only
  status. The future application still owns FileSystem/Path layers and its one
  runtime; this adapter creates no runtime or listener.
- Exclusive 0600 file reservation, separate version-1 schema initialization,
  create-disabled normal open, exact schema/application/version checks, bounded
  decoded rows and relations, no migration or reseeding of absent policy.
- Ledger WAL/FULL/FK/zero-timeout settings; rollback-journal ownership database
  bound to canonical path/device/inode identities. Lifetime `BEGIN EXCLUSIVE`
  on that separate database, never a ledger transaction across asynchronous work.
- Atomic replay, immutable decision-local evidence and receipts, revision
  history, persisted wall floor, unique transport/command/evidence keys, and
  trusted expected-revision policy updates. No permission cache or persisted
  monotonic ticks. Exact limits: 256/1024/256, including known replay at capacity.
- Final revision/wall/monotonic/evidence check after writes. A savepoint rolls
  back every decision/evidence/receipt key if that barrier refuses. Returned
  committed time is the final reading, not the earlier evaluation reading.
- Read-only validation uses one synchronous SQLite snapshot, including during
  status queries concurrent with another native connection's commit.
- Strict `close(true)` finalizers finalize cached statements; failed acquisitions
  close their child scope immediately. Native errors expose finite codes only.

## Path Policy Ruling And API Refinement

Applied the controller's arbitrary explicit custom production stateRoot ruling.
`LiveInboxConfig.pathPolicy` carries trusted host context separately from the
specified future CLI JSON: stateRoot, owner UID, home directory, repository/build/
temporary/sync exclusions and operator declaration of local non-synced storage.
The public config type and adapter README document these fields.

Both stateRoot and the database path are checked against exclusions. FileSystem
realpath checks cover every component; stateRoot and owned descendants require
0700, while safe OS ancestors need not be 0700. Files and sidecars require owner
UID, 0600 and one link. Dangling sidecar symlinks are rejected before SQLite open.
Path containment uses the admitted Path service, not string-prefix assumptions.

Native tests explicitly use `TestOwnedTemporary`; it is not a production
fallback. One synthetic FileSystem port case qualifies custom production-root
acceptance and descendant exclusion without touching external production paths.
It is not native production-filesystem proof.

## Tests And TDD Evidence

Native coverage includes absent/zero-byte/legacy/partial/wrong-scope/version/
corrupt/missing-policy and ownership failures; no byte repair or normal-open DDL;
owner-only permissions, WAL/SHM and rollback guard journal modes; symlinked final,
parent and dangling sidecars; inaccessible state and replaced backup identity;
actual child death, competing owners, credential-free status; races, rollback
fault points, exact capacity ceilings, policy revision races, exclusive expiry,
wall rollback across reopen, per-request monotonic leases and detached inputs.

Semantic RED -> GREEN records (all under `task-5-evidence/`):

| RED Log | Expected Failure Before Fix | GREEN Log |
| --- | --- | --- |
| `red-storage-export.log` | Missing explicit storage export | `storage-fifth-run.log` and final suite |
| `red-final-barrier.log` | Late expiry returned Recorded | `green-final-barrier.log` |
| `red-active-evidence.log` | Replay accepted a missing evidence row | `green-active-evidence.log` |
| `red-local-evidence-binding.log` | Local denial masked unrelated live evidence | `green-local-evidence-binding.log` |
| `red-schema-code.log` | Unsupported version returned generic InvalidData | `green-schema-code.log` |
| `red-dangling-sidecar-behavior.log` | Dangling WAL was not rejected by path policy | `green-dangling-sidecar-behavior.log` |
| `red-strict-close.log` | Owned close did not require finalization | `green-strict-close.log` |
| `red-status-snapshot.log` | Concurrent valid commit made status InvalidData | `green-status-snapshot.log` |
| `red-descendant-path.log` | Excluded descendant database was accepted | `green-descendant-path.log` and final suite |

The first expanded test attempt had a parser error, and initial schema/Effect API
mistakes and fixture errors are retained in the iteration logs. Those errors are
not counted as behavioral RED evidence. The initial broad batch does not provide
a clean per-behavior RED history; the explicit semantic regressions above do.
No failed test was blindly retried into green: implementation or identified
fixture corrections preceded reruns. No existing law counts or budgets changed.

The 01:15-era full sequential qualification passed on the earlier source; its
logs are preserved in `qualification-1/`. It does NOT qualify the subsequent
snapshot/path fixes. The earlier partial baseline and initial clarification
report are also preserved and are not completion evidence.

## Final Gates

All final commands use `env -i PATH="$PATH" HOME="$HOME" TMPDIR="$TMPDIR"`.
Frozen install required the authorized exact-command tempdir escalation; the
second final attempt's sandbox EPERM and successful output are both retained.
No source changes occur during the final block. The block runs sequentially and
stops on its first failure; `final-gates.sh` records the exact command order.

Final block completed successfully on the exact committed source:

- Frozen install: passed, unchanged dependencies/lock.
- `bun run check`: passed, zero warnings/errors and format clean.
- Five workspace typechecks: passed.
- `moon run domain:test --force --no-actions`: 211 pass, 0 fail.
- `moon run engine:test --force --no-actions`: 300 pass, 0 fail.
- `moon run probe:test --force --no-actions`: 36 pass, 0 fail.
- `moon run github-admission:test --force --no-actions`: 135 pass, 0 fail.
- `moon run github-adapter:test --force --no-actions`: 194 pass, 0 fail.
- Total: 876 pass, 0 fail. Adapter includes 25 storage/path cases.
- `git diff --check` and staged `git diff --cached --check`: passed.
- No github-ingress app workspace exists; only its not-yet-available gates omitted.

Every command log is `task-5-evidence/final-<gate>.log`; the final frozen install
is `final-install-2-sandbox.log` (successful scoped escalation), with the original
EPERM retained as `final-install-2-EPERM.log`. No failed final test suite was
retried. The earlier passing block was rerun only because the exact source
changed for the disclosed RED/GREEN self-review fixes.

Commit verification: all eight source-file SHA256 values, lock and patch hashes
matched after qualification; unstaged diff was empty; the committed tree matches
the pre-commit staged tree exactly; parent is c973 as above. Tracked worktree is
clean. Commit is local and unsigned; no signing secrets, merge or push used.
See `task-5-evidence/final-verification.json` and `final-source-verification.log`.

`final-dependency-audit.json` confirms all 141 bundled AND resolved Effect rule
severities are errors, one physical Effect 4.0.5 across all five workspaces,
unchanged platform-node-shared 4.0.5 override, and the same two approved patches.

Lock SHA256 remains
`d375b856e7760a67d0cf48ce683ee9d66ae14b75264c9cbe737ac1cf6bbe1de7`.
Flue patch remains
`07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a`;
Gaxios patch remains
`7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e`.
No lock/root override/lint config/patch/legacy probe/domain/engine changes.

## Self-Review And Concerns

Self-review found and fixed late expiry, active evidence integrity, local-denial
provenance, strict native finalization, status snapshot and descendant path issues
with the covering regressions above. No independent review claimed.

- Real Bun 1.4.2 SQLite and kernel-lock child-death qualification was performed
  locally on this macOS host. No cross-host, deployed or live GitHub proof.
- Operator declaration is required: pathname checks cannot establish absence of
  arbitrary sync software or network mounts. No such proof is claimed.
- Canonical file identity rejects moved/replaced backups; it is not cryptographic
  anti-rollback protection against malicious same-UID, same-inode overwrites.
- The inbox module is approximately 600 lines, kept within the requested file map
  rather than split into unrequested runtime/service modules.
- TDD-history limitation for the initial batch is stated above for controller
  review, not hidden behind the later passing suite.
- Retain Task 3 deferred minor M1 (memory inbox metadata mutation) and M2
  (permutation law) for final review. Neither was expanded or fixed here.

Changed files: adapter package manifest, README, three requested source modules,
two test files and one test-fixture module. Report/evidence remain only in this
ignored plan workspace. No controller progress/review edits, new dependencies,
rule waivers, real credentials/GitHub API use, Task 6 work, merge or push.

## Task 5 Fix Round 1

Addressed review findings Important I1 and I2 personally, without agents or
reviewers. Only `packages/github-adapter/src/live-sqlite-inbox.ts` and its
existing test file changed in tracked source. The production ownership guard,
path policy, storage schema, interfaces and runtime ownership are unchanged.

### I1: Independently Committed Native Writers

Two new deterministic tests use a real second Bun SQLite ledger connection,
not a second production owner resource. All drafts exist before its immediate
transaction commits. The first native transaction inserts a complete winner:
decision JSON, immutable evidence, and receipt. Driver commit of the same facts
with different proposed evidence returns the exact original `Duplicate`;
another operator with a distinct delivery returns `CommandConflict`. Exact SQL
row assertions retain only the winner's decision/evidence/receipt, excluding
both losing evidence identities and the conflicting receipt key.

The second test independently inserts the next policy snapshot and commits the
policy revision before driver commit of an already evaluated draft. The driver
returns `AuthorityChanged` without an `AfterDecision` write, and exact SQL/status
assertions show no decision, evidence or receipt keys. Existing native Busy and
rollback-EXCLUSIVE child-death ownership tests remain separate and unchanged.

### I2: Shared Synchronous Validation

`validateFresh(draft, policy, floor, accepted)` is the one synchronous validation
routine. Both prewrite and final validation call it, each taking a new schema-
decoded clock sample and reading policy in its own caller. Prewrite supplies
the persisted floor; final supplies the earlier record's committed wall time.
Revision, wall/monotonic evaluation barriers, evidence binding, lease validity
and decision equality retain their rejection ordering. Savepoint rollback and
finite sanitized errors are unchanged. No module, runtime, dependency or lint
waiver was introduced.

### RED/GREEN And Development Evidence

Evidence is under `task-5-evidence/fix-round-1/`; earlier logs are preserved.
The coverage additions qualify existing behavior, not a discovered production
race defect. The first new coverage run passed. After extraction, three explicit
temporary production mutations established meaningful RED sensitivity:

- `red-replay-mutation.log`: skipping transaction replay resolution fails the
  duplicate assertion with finite `InvalidData`, rather than returning winner.
- `red-operator-mutation.log`: ignoring immutable operator mismatch returns
  `Duplicate` instead of required `CommandConflict`.
- `red-policy-mutation.log`: bypassing the prewrite validator fails with finite
  `InvalidData` instead of required `AuthorityChanged`.

All mutations were restored immediately; none is in final source.
`green-storage.log` records 17 storage tests passing (1658 assertions), including
existing final-clock expiry/savepoint rollback coverage. A focused typecheck
found a union-spread fixture typing error; schema decoding corrected the fixture
and `focused-typecheck-corrected.log` passes. The failed diagnostic is retained
in `focused-typecheck.log`; no failed test was silently retried. The initial
implementation's TDD-history limitation remains disclosed and is not repaired
retroactively by these controls. `851` was a prior test count, not a base SHA.

### Final Qualification Identity

The unchanged-source sequential block completed successfully. The block is `gates.sh`;
`final-gates.log` records its order and each `final-<gate>.log` has raw output.
The frozen install's tempdir EPERM is preserved in `final-install-EPERM.log`;
the exact command passed with authorized scoped escalation and no dependency
changes. All commands use the minimal explicit environment from context.

`final-source-sha256.txt` pins the two changed source files, lock and patches.
`final-dependency-audit.json` confirms all 141 bundled/resolved Effect rules are
errors, one physical Effect 4.0.5, unchanged overrides and patched dependencies.
No github-ingress app workspace exists, so only its unavailable gates are
omitted. No Task 6 work was performed. Local synthetic/native qualification is
not live GitHub or deployment proof. Task 3 minor M1/M2 and the initial-history
concern remain for controller review.

Verified local fix commit:

- Commit: `bb2c3cd01fe355f76fbd327c79c64dc240f90937`
- Tree: `bea410fa0fdf070bee7d664a3a37deb506deee2b`
- Parent: `17ed64a823485c3c6093d7119889a6c8d6ee818c`
- Subject: `fix: qualify native inbox races and share commit validation`
- Branch: `codex/local-github-ingress`; tracked worktree clean after commit.
- Source SHA256: inbox `37cc653f07689507c7e1593ad010699ee8df2dd3fbf8e2858da61848cefae32c`;
  test `8d646f5a7a8ae6f68cbb58ce4cfa6584801acb99d40c4de7fa9d9737df76b0f4`.

Final gates, all exit 0: frozen install, lint/format, all five available
typechecks, all five available test suites and `git diff --check`.

| Suite | Pass | Fail |
| --- | ---: | ---: |
| domain | 211 | 0 |
| engine | 300 | 0 |
| probe | 36 | 0 |
| github-admission | 135 | 0 |
| github-adapter | 196 | 0 |
| Total | 878 | 0 |

Status: I1/I2 implemented and locally verified, ready for controller scoped
re-review. Initial TDD-history concern and deferred Task 3 M1/M2 remain. No
live proof is claimed; no Task 6, merge or push was performed.
