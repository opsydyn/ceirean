# Controller Evidence Handoff For Task 7

Read only when Task 7 is dispatched. This supplements its brief, not authority to
start Task 7 before Task 6 review.

- Preserve durable final raw gate logs, source identities, negative controls and
  task/final review reports before this plan-owned scratch directory is removed.
  Use a dedicated docs/evidence/local-github-ingress/ directory alongside the
  planned JSON manifest; do not archive private keys, environment dumps, arbitrary
  development scratch or a sibling plan's workspace.
- Distinguish initial task candidates and fixes. Task 4 final source is c973182;
  Task 5 final source bb2c3cd. Prior initial candidate logs do not qualify fixes.
- Relevant final evidence paths: task-1-evidence (see its report for final logs),
  task-2-evidence, task-3 report's fixed-source logs, task-4-evidence/round1/,
  task-5-evidence/fix-round-1/. Read each report to identify precise logs rather
  than guessing a directory means every contained run passed.
- Preserve review closures: task-1-review.md, task-2-review.md,
  task-3-review.md plus task-3-rereview-1.md, task-4-review.md plus
  task-4-rereview-1.md, task-5-review.md plus task-5-rereview-1.md, and the future
  Task 6/7/final review reports. Include every Ruling from progress.md in a durable
  execution-decision record, including its stated cost if wrong.
- Initial Task 5 broad-batch test-first history was incomplete. Disclose it;
  subsequent semantic RED/GREEN and passing suites cannot recreate that history.
- Deferred final triage: Task 3 M1 memory-inbox receipt metadata overwrite;
  M2 permutation law tests reversed pre-admitted duplicates rather than paired
  fresh histories; Moon update notices (not lint warnings). Do not silently drop
  these or alter tool pins/filter logs just to hide notices.
- Controller read installed `moon --help`: no specific update-notifier switch is
  advertised. `--quiet` hides all Moon output and is not an acceptable fix for
  an evidence log. This does not prove no supported notifier control exists.
- Full final gates must qualify the actual final production/test source, not an
  older source merely because evidence/docs are written later. Keep exact tested
  source/tree/lock identity distinct from subsequent evidence-only commits.
- The future whole-branch reviewer is controller-dispatched after Task 7's task
  review. No author-spawned review or merge/push/live rehearsal is authorized.
- Task 6 accidentally force-committed its report and selected evidence under the
  ignored SDD workspace in e8fb83c. After canonical durable archiving and hash
  verification, remove those tracked scratch copies from the index in Task 7
  while preserving local recovery files until final review. Do not rewrite
  history or delete unique evidence. Controller-owned ledger stays in scratch
  until its rulings/review closures are durably archived. Future reports remain
  untracked here; durable evidence lives under docs/evidence, not .superpowers.
