# Task 2 Report

Status: DONE. Implementation is committed; independent task review and ledger updates remain controller-owned.

## Scope And Source Identity

- Checkout: `/private/tmp/leviathan-compatibility` only.
- Branch: `codex/local-github-ingress`; no worktree creation or branch switching.
- Accepted parent: `50335af7f0c6077cfeee38045cb59fcb1be530a5`.
- Parent tree: `328ce0c53445b545df27627918a6133dd1c21ed0`.
- Task commit: `e3ce2537c291ca3936318feb787d3b4fe230be5d`.
- Committed tree: `6aace25ffef3707252c66b9c9cf0002cc608b383`.
- Message: `refactor: share verified GitHub protocol boundary`.
- Ten task files committed, 742 insertions and 423 deletions. Working tree clean after commit.
- Read only the Task 2 brief and binding context, not the full plan or prior-task history. No agents or reviewers spawned. No merge, push, external application API call, listener, tunnel, real credentials, or runtime fixture acquisition added or performed.

All paths below are checkout-relative. Exact command output is in `task-2-evidence/` beside this report. Ignored report/evidence/tooling files are not included in the code commit. No controller ledger or review file was edited.

## Files

| File | Change |
| --- | --- |
| `packages/github-adapter/package.json` | Explicit `./protocol` export; declare already-qualified `@flue/github: 2.3.0`, `@flue/runtime: 2.3.0`, `@leviathan/domain: workspace:*` before importing. |
| `packages/github-adapter/src/request-body.ts` | Exact move of qualified Effect capture and reader-ownership implementation, including cancellation-finalizer behavior and error class. |
| `packages/github-adapter/src/github-payload.ts` | Exact move of detached schema-validated native payload normalization. |
| `packages/github-adapter/src/verified-ingress.ts` | Shared factory, preflight, request-owned Flue channel, exact-byte verification, normalization and protocol rejection/error projection; exports capture/normalization functions and their existing supporting types. |
| `packages/github-adapter/tests/protocol.test.ts` | Thirteen real synthetic-signature tests of callback, digest, rejection, slow-body abortion, held/rejected cancellation, and overflow contracts. |
| `probes/github-admission/src/request-body.ts` | Small static old-path forwarding module; same exported error identity and types. |
| `probes/github-admission/src/github-payload.ts` | Small static old-path normalization forwarding module. |
| `probes/github-admission/src/github-ingress.ts` | Retain `makeGitHubIngress` and `IngressFailure`; wrapper owns legacy AdmissionReply decoding and response/status mapping. |
| `probes/github-admission/package.json` | Explicit private adapter workspace dependency. |
| `bun.lock` | Only the four matching workspace dependency declarations; no package artifact/cohort delta. |

## Boundary And Parity

`makeVerifiedGitHubIngress({ secret, ingressScopeId, capture, onVerified })` exposes `fetch(Request): Promise<Response>`. A successful real Flue verification and valid normalization call `onVerified(VerifiedCommand)` once, returning the application's Response unchanged. The application owns the capture runner and successful response projection. The protocol creates no ManagedRuntime, Layer, inbox, storage, fixtures, admission service or authority policy.

The legacy wrapper snapshots config/callable identities as before, schema-decodes AdmissionReply, serializes Recorded/Duplicate responses unchanged, and preserves Unrecorded mappings: FieldTooLarge 413, MalformedInput 400, DeliveryConflict/CommandConflict/AuthorityChanged/CapacityExceeded 409, other reasons 200. Protocol-only normalization failures retain their former envelopes and 400/413/200 mapping; malformed transport, signature and operational statuses remain unchanged.

Both extracted capture/normalization source files are byte-for-byte identical to their parent versions (`self-review-verified.json`). All old probe tests are untouched, rather than rewritten to accept new outcomes. Their application tests continue to exercise SQLite rows, callback failures, replay/conflicts, concurrent deliveries, disposal, and secret/error redaction through the same historical import paths.

The digest test signs two differently spaced byte bodies with the same delivery ID and same normalized command. Both callbacks receive their independently computed original SHA-256 values, which differ. It does not insert replay/ledger conflict policy into transport.

Cancellation tests capture the pending state before allowing cancellation to resolve/reject: response unsettled, reader locked, one cancellation, zero callbacks. After settlement the reader is unlocked and no callback occurred. No timeout or false successful disposal is introduced; the existing pending-cancellation ownership remains intact.

## RED And GREEN

Used the required TDD skill and `apply_patch` for all manual code edits. Added the initial protocol tests before production extraction or the export existed. Kept old tests unchanged throughout.

- `red.log`: `bun --no-env-file --no-install test packages/github-adapter/tests/protocol.test.ts` exited 1 with the expected missing `@leviathan/github-adapter/protocol` module/export failure (0 pass, 1 fail, 1 import error). This was the brief's explicit missing-export RED, not a behavioral assertion failure.
- Workspace linking initially hit sandbox `tempdir: EPERM`, even with writable TMPDIR. `workspace-link.log` and `workspace-link-offline.log` retain those outputs. The initial GREEN attempt consequently still lacked `@flue/github`; it did not establish parity.
- Scoped escalation allowed Bun to link the declared, accepted dependencies with scripts disabled (`workspace-link-escalated.log`). No lock package resolution entries changed. No new pin or artifact cohort was admitted.
- `green-initial.log`: after correct links, initial five protocol tests passed (20 assertions).
- `green-expanded.log`: all thirteen protocol tests passed (57 assertions), including the added security/cleanup characterization tests against the extracted implementation.
- Development lint exposed test-helper style violations, then one deep pure-pipeline violation; development typecheck exposed unbranded expected digest types. Fixed the test helpers using Effect Match/Struct/Schema and branded independently computed digests, without changing rules or production semantics. Logs retained under `lint-development*.log` and `typecheck-development*.log`.
- `lint-development-clean.log`: 0 warnings/errors. `typecheck-development-ready.log`: strict adapter typecheck passes.
- Final focused GREEN on final source: `bun --no-env-file --no-install test packages/github-adapter/tests/protocol.test.ts probes/github-admission/tests/request-body.test.ts probes/github-admission/tests/github-payload.test.ts probes/github-admission/tests/github-ingress.test.ts`.
- `green-focused-final.log`: 96 passed, 0 failed, 363 assertions across 4 files. This is 13 new protocol tests plus 83 unchanged legacy focused tests.

Focused commands used `env -i PATH="$PATH" HOME="$HOME" TMPDIR=/private/tmp`. There was no repeated pre-change baseline. Failed development checks were corrected for their recorded causes; no failing suite was blindly retried into green.

## One Final Full Gate Block

Executed exactly once, sequentially, through `task-2-gates.sh` on the final code/test source before staging and commit. Every command ran under `env -i PATH="$PATH" HOME="$HOME" TMPDIR="$TMPDIR"`, with the script invocation explicitly setting TMPDIR to `/private/tmp`. Only PATH, HOME and TMPDIR were supplied; no credentials. Scoped escalation addressed Bun temp access/tool cache permissions, not product behavior. Every gate has exact `.command`, `.log` and `.exit` evidence; all thirteen exit files contain 0. The script stops on a nonzero exit. There were no final-block failures or reruns.

| Evidence prefix | Command | Actual result |
| --- | --- | --- |
| `01-install` | `bun install --frozen-lockfile --ignore-scripts` | pass |
| `02-check` | `bun run check` | pass: 0 warnings/errors; lint 102 files/210 total rules; format 153 files |
| `03-domain-typecheck` | `moon run domain:typecheck --force --no-actions` | pass |
| `04-engine-typecheck` | `moon run engine:typecheck --force --no-actions` | pass |
| `05-probe-typecheck` | `moon run probe:typecheck --force --no-actions` | pass |
| `06-github-admission-typecheck` | `moon run github-admission:typecheck --force --no-actions` | pass |
| `07-github-adapter-typecheck` | `moon run github-adapter:typecheck --force --no-actions` | pass |
| `08-domain-test` | `moon run domain:test --force --no-actions` | 201 pass, 0 fail, 768 assertions, 8 files |
| `09-engine-test` | `moon run engine:test --force --no-actions` | 273 pass, 0 fail, 1526 assertions, 14 files |
| `10-probe-test` | `moon run probe:test --force --no-actions` | 36 pass, 0 fail, 104 assertions, 7 files |
| `11-github-admission-test` | `moon run github-admission:test --force --no-actions` | 135 pass, 0 fail, 1828 assertions, 10 files |
| `12-github-adapter-test` | `moon run github-adapter:test --force --no-actions` | 17 pass, 0 fail, 74 assertions, 2 files |
| `13-diff-check` | `git diff --check` | pass |

Full block total: 662 passed, 0 failed, 4300 assertions across 41 test files. No cached/affected-only substitute or root unfiltered Bun test command. `github-ingress` does not exist yet; only its typecheck/test gates were omitted as permitted by the available-workspace rule. All existing law sources and budgets are unchanged, including 1000 runs at seeds 0/1/163 with size 50, maxShrinks 1000, maxDiscards 10000. The full domain/engine laws ran, rather than being reduced for this extraction.

## Dependency And Source Audit

`audit-final.json` contains every one of the 141 Effect rule names and resolved severity/options, per-file SHA-256 identities, root override and physical Effect resolution. `self-review-verified.json` contains the accepted parent identity, exact extraction equivalence, unchanged-path checks and full lock delta. Earlier `audit.json`/`self-review*.json` record diagnostic script path-resolution errors; these are not gate results. Corrected final audit scripts exit 0.

- Bun used: 1.4.2; Effect remains 4.0.5, Flue remains 2.3.0; accepted dependency pins and existing XState pins unchanged. Node 24.15.0 was used only for local audit tooling, not a controller fallback.
- `skipLibCheck: false` and Moon task settings unchanged.
- All 141 Effect rules are errors universally under the existing config; no disables, new ignores, waivers, helper provisioning, manual Effect/Layer channels, direct Hono/Octokit imports or dynamic imports added.
- Root override unchanged: `@effect/platform-node-shared: 4.0.5`.
- All five workspace Effect imports and Flue runtime resolution point to `/private/tmp/leviathan-compatibility/node_modules/.bun/effect@4.0.5/node_modules/effect`; exactly one physical `effect@` installation.
- Accepted parent lock SHA-256: `74b793ca8c86d8dc38cad063675ce8be1f85cafc8241aae979f96a0b31e6f014`.
- Final lock SHA-256: `13d9d8d647dc949b236108c7a5fc8a6d7798164583c5b4ed0d6c221af10e3e73`.
- The context's older baseline `a03b2f20874301814ba165f945b3fa55df5f20023f29ba5b873f3d16537cadc3` is not the lock at the explicitly accepted Task 1 HEAD. Used the user's accepted HEAD/manifest/root lock as authoritative, rather than reverting its qualification.
- Flue patch SHA-256 unchanged: `07d115c8c98bea3c28011afe76e838a89a5126b2f401bad1091af678c008931a`.
- Gaxios patch SHA-256 unchanged: `7ea7b1f29d158ab1595b71f798b71c9c44249ae29567b12dcf6d5d7e35239e3e`.
- `request-body.ts`: `6023cdbffc82590882578d2a677ec3831c859a7449d9fae071869d118bfa49a3`.
- `github-payload.ts`: `5392debc4ae1d14f632d90e5d4812ecd1c40dc4cd11e68d247cacd213555369d`.
- `verified-ingress.ts`: `cbf4c13dbb5384785ee6844f7c8d1ec4b072bd61403d676ab02492c4b1ab5890`.
- `protocol.test.ts`: `4dde82796f9d7d75cbbbb6bc37d0091824802eccbd6533770cd026c62b728f76`.

## Self-Review And Concerns

Reviewed the extraction and wrapper diff for exported-symbol identity, detached normalization, signature-before-callback ordering, original digest preservation, request-local Flue channels, callback error sanitization, legacy response mapping and asynchronous cancellation ownership. Verified no changes to domain, engine, legacy tests, root manifest, config, patches, adapter strict tsconfig or Moon tasks. Staged only the ten task files; staged diff check passed before commit. Commit output is in `commit.log`.

No implementation blocker or unresolved failing test found. The older context lock hash and sandbox installation/audit-script failures are recorded above to distinguish them from the accepted parent identity and successful final gates. This is synthetic/local protocol parity evidence, not live GitHub acceptance, listener qualification, live admission/storage implementation, independent review, or authorization for Task 3. Independent review remains the controller's next gate; no review was spawned and no ledger was updated.
