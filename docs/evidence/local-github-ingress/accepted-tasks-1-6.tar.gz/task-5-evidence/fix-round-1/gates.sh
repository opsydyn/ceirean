#!/bin/sh
set -eu
evidence=.superpowers/sdd/2026-10-20-local-github-ingress/task-5-evidence/fix-round-1
run() {
  name=$1
  shift
  printf '%s\n' "RUN $name: $*"
  if "$@" > "$evidence/final-$name.log" 2>&1; then
    printf '%s\n' "PASS $name"
  else
    code=$?
    printf '%s\n' "FAIL $name ($code)"
    tail -n 60 "$evidence/final-$name.log"
    exit "$code"
  fi
}
# Frozen install is recorded separately immediately before this block.
run check bun run check
run domain-typecheck moon run domain:typecheck --force --no-actions
run engine-typecheck moon run engine:typecheck --force --no-actions
run probe-typecheck moon run probe:typecheck --force --no-actions
run github-admission-typecheck moon run github-admission:typecheck --force --no-actions
run github-adapter-typecheck moon run github-adapter:typecheck --force --no-actions
# Task 6's github-ingress workspace does not exist.
run domain-test moon run domain:test --force --no-actions
run engine-test moon run engine:test --force --no-actions
run probe-test moon run probe:test --force --no-actions
run github-admission-test moon run github-admission:test --force --no-actions
run github-adapter-test moon run github-adapter:test --force --no-actions
run diff-check git diff --check
